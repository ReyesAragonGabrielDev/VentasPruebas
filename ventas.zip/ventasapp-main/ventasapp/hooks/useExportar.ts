import { useCallback } from 'react';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system';
import { Platform } from 'react-native';
import type { VentaConItems } from './useVentas';

// ─── Helpers ────────────────────────────────────────────────────────────────

function formatFecha(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString('es-MX', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function formatHora(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
}

function formatCoords(lat: number | null, lng: number | null) {
  if (!lat || !lng) return '---';
  return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
}

// ─── Hook ────────────────────────────────────────────────────────────────────

export function useExportar() {

  // ── PDF ──────────────────────────────────────────────────────────────────
  const exportarPDF = useCallback(async (ventas: VentaConItems[], simbolo: string) => {
    if (ventas.length === 0) return { ok: false, error: 'Sin datos para exportar' };

    // Columnas dinámicas por producto
    const nombresProductos = Array.from(
      new Set(ventas.flatMap(v => v.items.map(i => i.nombre_producto)))
    ).sort();

    const totalGeneral = ventas.reduce((acc, v) => acc + Number(v.total), 0);

    const filas = ventas.map(v => {
      const celdas = nombresProductos.map(nombre => {
        const item = v.items.find(i => i.nombre_producto === nombre);
        return `<td>${item ? item.cantidad : '-'}</td>`;
      }).join('');

      return `
        <tr>
          <td>${formatFecha(v.created_at)}</td>
          <td>${formatHora(v.created_at)}</td>
          <td>${formatCoords(v.latitud, v.longitud)}</td>
          ${celdas}
          <td class="total">${simbolo}${Number(v.total).toFixed(2)}</td>
        </tr>`;
    }).join('');

    const encabezados = nombresProductos
      .map(n => `<th>${n}</th>`)
      .join('');

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; font-size: 11px; color: #1A1A2E; padding: 20px; }
            h1  { font-size: 20px; color: #E94560; margin-bottom: 4px; }
            p   { color: #888; font-size: 10px; margin-bottom: 16px; }
            table { width: 100%; border-collapse: collapse; }
            th  { background: #E94560; color: #FFF; padding: 8px 6px; text-align: center; font-size: 10px; }
            td  { padding: 7px 6px; text-align: center; border-bottom: 1px solid #EEE; }
            tr:nth-child(even) td { background: #F9F9F9; }
            .total { color: #E94560; font-weight: bold; }
            .footer { margin-top: 16px; text-align: right; font-size: 12px; font-weight: bold; }
          </style>
        </head>
        <body>
          <h1>VentasApp — Historial</h1>
          <p>Generado el ${new Date().toLocaleString('es-MX')}</p>
          <table>
            <thead>
              <tr>
                <th>Fecha</th><th>Hora</th><th>Ubicación</th>
                ${encabezados}
                <th>Total</th>
              </tr>
            </thead>
            <tbody>${filas}</tbody>
          </table>
          <div class="footer">
            Total general: ${simbolo}${totalGeneral.toFixed(2)}
          </div>
        </body>
      </html>`;

    try {
      const { uri } = await Print.printToFileAsync({ html, base64: false });
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Exportar historial PDF',
        UTI: 'com.adobe.pdf',
      });
      return { ok: true };
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  }, []);

  // ── EXCEL (CSV compatible con Excel) ─────────────────────────────────────
  const exportarExcel = useCallback(async (ventas: VentaConItems[], simbolo: string) => {
    if (ventas.length === 0) return { ok: false, error: 'Sin datos para exportar' };

    const nombresProductos = Array.from(
      new Set(ventas.flatMap(v => v.items.map(i => i.nombre_producto)))
    ).sort();

    // Encabezado CSV
    const headerRow = [
      'Fecha', 'Hora', 'Ubicacion',
      ...nombresProductos,
      'Total', 'Moneda'
    ].join(',');

    // Filas de datos
    const dataRows = ventas.map(v => {
      const cantidades = nombresProductos.map(nombre => {
        const item = v.items.find(i => i.nombre_producto === nombre);
        return item ? item.cantidad : 0;
      });
      return [
        formatFecha(v.created_at),
        formatHora(v.created_at),
        formatCoords(v.latitud, v.longitud),
        ...cantidades,
        Number(v.total).toFixed(2),
        v.moneda,
      ].join(',');
    });

    // Fila de totales
    const totalesPorProducto = nombresProductos.map(nombre =>
      ventas.reduce((acc, v) => {
        const item = v.items.find(i => i.nombre_producto === nombre);
        return acc + (item ? item.cantidad : 0);
      }, 0)
    );
    const totalGeneral = ventas.reduce((acc, v) => acc + Number(v.total), 0);
    const totalRow = [
      'TOTAL', '', '',
      ...totalesPorProducto,
      totalGeneral.toFixed(2),
      ventas[0]?.moneda ?? 'MXN',
    ].join(',');

    // BOM para que Excel abra bien el UTF-8
    const bom = '\uFEFF';
    const csv = bom + [headerRow, ...dataRows, totalRow].join('\n');

    try {
      const fecha = new Date().toISOString().slice(0, 10);
      const filename = `ventasapp_${fecha}.csv`;
      const fileUri = FileSystem.documentDirectory + filename;

      await FileSystem.writeAsStringAsync(fileUri, csv, {
        encoding: FileSystem.EncodingType.UTF8,
      });

      await Sharing.shareAsync(fileUri, {
        mimeType: 'text/csv',
        dialogTitle: 'Exportar historial Excel/CSV',
        UTI: 'public.comma-separated-values-text',
      });
      return { ok: true };
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  }, []);

  return { exportarPDF, exportarExcel };
}
