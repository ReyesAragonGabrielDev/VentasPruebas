import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface ItemCarrito {
  producto: { id: string; nombre: string; precio: number };
  cantidad: number;
}

export interface VentaConItems {
  id: string;
  total: number;
  moneda: string;
  latitud: number | null;
  longitud: number | null;
  created_at: string;
  items: Array<{
    id: string;
    producto_id: string;
    nombre_producto: string;
    precio_unitario: number;
    cantidad: number;
    subtotal: number;
  }>;
}

export function useVentas() {
  const [ventas, setVentas]                   = useState<VentaConItems[]>([]);
  const [enviando, setEnviando]               = useState(false);
  const [loadingHistorial, setLoadingHistorial] = useState(false);

  const enviarVenta = useCallback(async (
    items: ItemCarrito[],
    moneda: string,
    coords: { latitud: number | null; longitud: number | null }
  ) => {
    setEnviando(true);
    const total = items.reduce((acc, i) => acc + i.producto.precio * i.cantidad, 0);

    const { data: vData, error: vErr } = await supabase
      .from('ventas')
      .insert({ total, moneda, latitud: coords.latitud, longitud: coords.longitud })
      .select('id')
      .single();

    if (vErr) { setEnviando(false); return { ok: false, error: vErr.message }; }

    const itemsPayload = items.map(i => ({
      venta_id: vData.id,
      producto_id: i.producto.id,
      nombre_producto: i.producto.nombre,
      precio_unitario: i.producto.precio,
      cantidad: i.cantidad,
      subtotal: i.producto.precio * i.cantidad,
    }));

    const { error: iErr } = await supabase.from('venta_items').insert(itemsPayload);
    setEnviando(false);
    return { ok: !iErr, error: iErr?.message };
  }, []);

  const cargarHistorial = useCallback(async (desde?: string, hasta?: string) => {
    setLoadingHistorial(true);
    let query = supabase
      .from('ventas')
      .select('*, items:venta_items(*)')
      .order('created_at', { ascending: false });

    if (desde) query = query.gte('created_at', desde);
    if (hasta) query = query.lte('created_at', hasta);

    const { data, error } = await query;
    if (!error) setVentas(data || []);
    setLoadingHistorial(false);
  }, []);

  return { ventas, enviando, loadingHistorial, enviarVenta, cargarHistorial };
}
