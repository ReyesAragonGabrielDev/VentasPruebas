// import { useState, useCallback } from 'react';
// import * as Location from 'expo-location';

// export function useLocation() {
//   const [permiso, setPermiso] = useState<'granted' | 'denied' | 'unknown'>('unknown');

//   const solicitarPermiso = useCallback(async () => {
//     const { status } = await Location.requestForegroundPermissionsAsync();
//     const result = status === 'granted' ? 'granted' : 'denied';
//     setPermiso(result);
//     return result;
//   }, []);

//   const obtenerCoordenadas = useCallback(async (): Promise<{
//     latitud: number | null;
//     longitud: number | null;
//   }> => {
//     try {
//       const { status } = await Location.getForegroundPermissionsAsync();
//       if (status !== 'granted') return { latitud: null, longitud: null };

//       const loc = await Location.getCurrentPositionAsync({
//         accuracy: Location.Accuracy.Balanced,
//       });
//       return {
//         latitud: loc.coords.latitude,
//         longitud: loc.coords.longitude,
//       };
//     } catch {
//       // GPS no disponible — no bloqueamos la venta
//       return { latitud: null, longitud: null };
//     }
//   }, []);

//   return { permiso, solicitarPermiso, obtenerCoordenadas };
// }























import { useState, useCallback } from 'react';
import * as Location from 'expo-location';

export function useLocation() {
  const [permiso, setPermiso] = useState<'granted' | 'denied' | 'unknown'>('unknown');

  const solicitarPermiso = useCallback(async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      const result = status === 'granted' ? 'granted' : 'denied';
      setPermiso(result);
      return result;
    } catch {
      return 'denied';
    }
  }, []);

  const obtenerCoordenadas = useCallback(async () => {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status !== 'granted') return { latitud: null, longitud: null };

      // Agregamos timeout de 5 segundos para que la app no se trabe
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
        timeInterval: 5000,
      });

      return {
        latitud: loc.coords.latitude,
        longitud: loc.coords.longitude,
      };
    } catch (error) {
      console.log("Error obteniendo GPS:", error);
      return { latitud: null, longitud: null };
    }
  }, []);

  return { permiso, solicitarPermiso, obtenerCoordenadas };
}
