import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Producto, ProductoInsert, ProductoUpdate } from '@/types/database';

export function useProductos() {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [loading, setLoading] = useState(true);

  const cargarProductos = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('productos')
      .select('*')
      .eq('activo', true)
      .order('created_at', { ascending: false });
    if (!error) setProductos(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { cargarProductos(); }, [cargarProductos]);

  const crear = useCallback(async (payload: ProductoInsert) => {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from('productos')
      .insert([{ ...payload, activo: true, user_id: user?.id }])
      .select();
    if (!error && data) setProductos(prev => [data[0], ...prev]);
    return { ok: !error, error: error?.message };
  }, []);

  const actualizar = useCallback(async (id: string, payload: ProductoUpdate) => {
    const { data, error } = await supabase
      .from('productos')
      .update(payload)
      .eq('id', id)
      .select();
    if (!error && data) setProductos(prev => prev.map(p => p.id === id ? data[0] : p));
    return { ok: !error, error: error?.message };
  }, []);

  const eliminar = useCallback(async (id: string) => {
    const { error } = await supabase
      .from('productos')
      .update({ activo: false })
      .eq('id', id);
    if (!error) setProductos(prev => prev.filter(p => p.id !== id));
    return { ok: !error, error: error?.message };
  }, []);

  return { productos, loading, refetch: cargarProductos, crear, actualizar, eliminar };
}
