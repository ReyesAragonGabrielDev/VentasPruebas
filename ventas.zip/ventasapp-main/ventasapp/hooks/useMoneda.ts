import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const MONEDA_KEY = 'ventasapp:moneda';
export const MONEDAS = ['MXN', 'USD', 'EUR'] as const;
export type Moneda = typeof MONEDAS[number];

export const SIMBOLOS: Record<Moneda, string> = {
  MXN: '$',
  USD: 'US$',
  EUR: '€',
};

export function useMoneda() {
  const [moneda, setMoneda] = useState<Moneda>('MXN');

  useEffect(() => {
    AsyncStorage.getItem(MONEDA_KEY).then((val) => {
      if (val && MONEDAS.includes(val as Moneda)) {
        setMoneda(val as Moneda);
      }
    });
  }, []);

  const cambiarMoneda = useCallback((m: Moneda) => {
    setMoneda(m);
    AsyncStorage.setItem(MONEDA_KEY, m);
  }, []);

  return { moneda, simbolo: SIMBOLOS[moneda], cambiarMoneda };
}
