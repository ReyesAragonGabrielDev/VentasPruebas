// Todas las validaciones de datos del usuario viven aquí.
// Se valida del lado cliente ANTES de enviar a Supabase.
// Supabase tiene sus propios CHECK constraints como segunda línea.

export type ValidationResult = { ok: true } | { ok: false; message: string };

export function validateProducto(
  nombre: string,
  precio: string
): ValidationResult {
  const n = nombre.trim();
  if (n.length === 0) return { ok: false, message: 'El nombre es obligatorio.' };
  if (n.length > 30) return { ok: false, message: 'El nombre no puede superar 30 caracteres.' };

  const p = parseFloat(precio.replace(',', '.'));
  if (isNaN(p) || p <= 0) return { ok: false, message: 'El precio debe ser mayor a $0.' };
  if (p > 999999.99) return { ok: false, message: 'Precio demasiado alto.' };

  return { ok: true };
}

export function validateCantidad(value: string): ValidationResult {
  const n = parseInt(value, 10);
  if (isNaN(n) || n < 0) return { ok: false, message: 'Cantidad inválida.' };
  if (n > 9999) return { ok: false, message: 'Cantidad máxima: 9999.' };
  return { ok: true };
}

/** Sanitiza texto libre removiendo caracteres de control */
export function sanitizeText(value: string): string {
  // eslint-disable-next-line no-control-regex
  return value.replace(/[\u0000-\u001F\u007F]/g, '').trim();
}

/** Parsea precio con seguridad */
export function parsePrecio(value: string): number {
  const n = parseFloat(value.replace(',', '.'));
  return isNaN(n) ? 0 : Math.max(0, parseFloat(n.toFixed(2)));
}
