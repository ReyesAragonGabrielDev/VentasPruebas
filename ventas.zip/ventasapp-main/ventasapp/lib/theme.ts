export const Colors = {
  // Fondos
  bgDark: '#07070F',
  surfaceDark: '#0E0E1C',
  cardDark: '#1C1C2E',
  cardDark2: '#181828',
  inputDark: '#242438',

  bgLight: '#F3F3F9',
  surfaceLight: '#FFFFFF',
  cardLight: '#FFFFFF',

  // Acentos
  red: '#E94560',
  redLight: '#FF6B6B',
  green: '#06D6A0',
  blue: '#4FC3F7',
  yellow: '#FFD166',

  // Texto oscuro
  textDark: '#F0F0FF',
  textDark2: '#6868A0',
  textDark3: 'rgba(255,255,255,0.25)',
  borderDark: 'rgba(255,255,255,0.06)',

  // Texto claro
  textLight: '#1A1A2E',
  textLight2: '#9090AA',
  textLight3: '#B0B0C0',
  borderLight: '#E0E0EE',
} as const;

export const Fonts = {
  regular: 'System',
  weight: {
    normal: '400' as const,
    semibold: '600' as const,
    bold: '700' as const,
    extrabold: '800' as const,
  },
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};
