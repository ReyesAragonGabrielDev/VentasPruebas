import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

// ─── Validación en tiempo de ejecución ──────────────────────────
// Si las variables no están definidas, la app falla con un mensaje
// claro en lugar de un error críptico de red.
const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseUrl.startsWith('https://')) {
  throw new Error(
    'EXPO_PUBLIC_SUPABASE_URL no está configurada o es inválida.\n' +
    'Copia .env.example como .env y pega tu URL de Supabase.'
  );
}

if (!supabaseAnonKey || supabaseAnonKey.length < 100) {
  throw new Error(
    'EXPO_PUBLIC_SUPABASE_ANON_KEY no está configurada o es inválida.\n' +
    'Copia .env.example como .env y pega tu Anon Key de Supabase.'
  );
}

// ─── Cliente Supabase ────────────────────────────────────────────
// Usamos SecureStore-compatible AsyncStorage para persistir la sesión.
// La anon key es pública por diseño: la seguridad real viene de las
// Row Level Security (RLS) policies en Supabase.
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
  global: {
    headers: {
      // Identifica la app en logs de Supabase
      'x-app-name': 'ventasapp',
    },
  },
});
