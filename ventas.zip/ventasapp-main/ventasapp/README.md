# ventas — App multiplataforma de ventas

React Native · Expo · Supabase

---

## ⚡ Setup en 5 pasos

### 1. Clona e instala

```bash
git clone https://github.com/TU_USUARIO/ventasapp.git
cd ventasapp
npm install
```

### 2. Crea el schema en Supabase

1. Ve a [supabase.com](https://supabase.com) → tu proyecto (o crea uno nuevo)
2. Entra a **SQL Editor → New query**
3. Pega el contenido de `sql/schema.sql` y presiona **Run**

### 3. Copia tus credenciales

```bash
cp .env.example .env
```

Abre `.env` y reemplaza los valores:

```
EXPO_PUBLIC_SUPABASE_URL=https://xxxxxxxxxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJ...
```

Las encontrarás en: **Supabase Dashboard → Settings → API**

> ⚠️ NUNCA subas el archivo `.env` a GitHub. Ya está en `.gitignore`.

### 4. Corre la app

```bash
npx expo start
```

- Escanea el QR con **Expo Go** (Android/iOS)
- Presiona `a` para Android emulador
- Presiona `i` para iOS simulador

### 5. Build para producción (EAS)

```bash
npm install -g eas-cli
eas login
eas build --platform android   # APK/AAB para Play Store
eas build --platform ios       # IPA para App Store
```

---

## 🏗 Estructura

```
ventasapp/
├── app/
│   ├── _layout.tsx          # Root layout + providers
│   └── (tabs)/
│       ├── _layout.tsx      # Tab bar
│       ├── index.tsx        # 🛒 Inicio — contador de ventas
│       ├── historial.tsx    # 📋 Historial con filtros
│       └── config.tsx       # ⚙️ Productos + ajustes
├── components/
│   ├── ThemeContext.tsx      # Contexto global de tema
│   ├── ProductoCard.tsx      # Tarjeta con contador
│   ├── NumpadModal.tsx       # Teclado numérico
│   └── Toast.tsx             # Notificaciones
├── hooks/
│   ├── useProductos.ts       # CRUD productos
│   ├── useVentas.ts          # Envío e historial
│   ├── useTheme.ts           # Tema persistido
│   ├── useMoneda.ts          # Moneda persistida
│   └── useLocation.ts        # GPS
├── lib/
│   ├── supabase.ts           # Cliente (con validación)
│   ├── theme.ts              # Design tokens
│   └── validation.ts         # Validación/sanitización
├── types/
│   └── database.ts           # Tipos TypeScript del schema
└── sql/
    └── schema.sql            # Schema completo con RLS
```

---

## 🔒 Seguridad implementada

| Capa | Medida |
|------|--------|
| **Secrets** | `.env` en `.gitignore`, nunca en código |
| **Supabase** | Row Level Security (RLS) activado en todas las tablas |
| **DB constraints** | `CHECK` en precios, cantidades, longitudes de texto |
| **Soft delete** | Productos se marcan `activo=false`, historial intacto |
| **Input** | Sanitización + validación antes de cualquier query |
| **Tipos** | TypeScript estricto en todo el proyecto |
| **Snapshot** | Ventas guardan nombre/precio al momento — resistente a cambios futuros |

---

## 📋 Tablas Supabase

| Tabla | Descripción |
|-------|-------------|
| `productos` | Catálogo con soft-delete |
| `ventas` | Cabecera: total, moneda, GPS, fecha |
| `venta_items` | Detalle: snapshot nombre/precio/cantidad |

---

## 🤝 Contribuir

1. Fork → rama → PR
2. `npm run lint` antes de hacer commit
