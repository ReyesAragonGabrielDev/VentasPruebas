-- ═══════════════════════════════════════════════════════════════════
-- VentasApp — Esquema Supabase
-- Ejecuta este script en: Supabase Dashboard → SQL Editor → New query
-- ═══════════════════════════════════════════════════════════════════

-- ─── Extensiones ─────────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ─── Tabla: productos ────────────────────────────────────────────
create table if not exists public.productos (
  id          uuid primary key default uuid_generate_v4(),
  nombre      text not null check (char_length(trim(nombre)) between 1 and 30),
  precio      numeric(10, 2) not null check (precio > 0),
  descripcion text check (descripcion is null or char_length(descripcion) <= 60),
  activo      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Índice para listar solo los activos rápido
create index if not exists idx_productos_activo on public.productos (activo);

-- ─── Tabla: ventas ───────────────────────────────────────────────
create table if not exists public.ventas (
  id         uuid primary key default uuid_generate_v4(),
  total      numeric(10, 2) not null check (total > 0),
  moneda     text not null default 'MXN' check (char_length(moneda) <= 5),
  latitud    double precision check (latitud is null or (latitud between -90 and 90)),
  longitud   double precision check (longitud is null or (longitud between -180 and 180)),
  created_at timestamptz not null default now()
);

-- Índice para historial ordenado por fecha
create index if not exists idx_ventas_created_at on public.ventas (created_at desc);

-- ─── Tabla: venta_items ──────────────────────────────────────────
-- Guardamos snapshot del nombre y precio para que el historial
-- sea fiel incluso si el producto cambia después.
create table if not exists public.venta_items (
  id               uuid primary key default uuid_generate_v4(),
  venta_id         uuid not null references public.ventas (id) on delete cascade,
  producto_id      uuid not null references public.productos (id) on delete restrict,
  nombre_producto  text not null check (char_length(nombre_producto) between 1 and 30),
  precio_unitario  numeric(10, 2) not null check (precio_unitario > 0),
  cantidad         integer not null check (cantidad > 0 and cantidad <= 9999),
  subtotal         numeric(10, 2) not null check (subtotal > 0)
);

create index if not exists idx_venta_items_venta_id on public.venta_items (venta_id);

-- ─── Trigger: updated_at automático ─────────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_productos_updated_at on public.productos;
create trigger trg_productos_updated_at
  before update on public.productos
  for each row execute function public.set_updated_at();

-- ─── Row Level Security (RLS) ────────────────────────────────────
-- La anon key de Supabase es pública. RLS es la única barrera
-- real entre internet y tus datos. Siempre actívala.

alter table public.productos enable row level security;
alter table public.ventas enable row level security;
alter table public.venta_items enable row level security;

-- POLÍTICA: Solo usuarios autenticados pueden leer/escribir.
-- Si la app es de uso personal sin login, usa la política anon abajo.

-- Opción A — App personal (sin autenticación, acceso anon):
create policy "anon_read_productos"  on public.productos  for select using (true);
create policy "anon_write_productos" on public.productos  for all    using (true) with check (true);
create policy "anon_read_ventas"     on public.ventas     for select using (true);
create policy "anon_insert_ventas"   on public.ventas     for insert with check (true);
create policy "anon_read_items"      on public.venta_items for select using (true);
create policy "anon_insert_items"    on public.venta_items for insert with check (true);

-- Opción B — Con autenticación (comenta la Opción A y descomenta esto):
-- create policy "auth_all_productos"   on public.productos   for all using (auth.role() = 'authenticated');
-- create policy "auth_all_ventas"      on public.ventas      for all using (auth.role() = 'authenticated');
-- create policy "auth_all_items"       on public.venta_items for all using (auth.role() = 'authenticated');

-- ─── Vista: historial con items ──────────────────────────────────
create or replace view public.v_historial as
  select
    v.id,
    v.total,
    v.moneda,
    v.latitud,
    v.longitud,
    v.created_at,
    json_agg(
      json_build_object(
        'id',              vi.id,
        'producto_id',     vi.producto_id,
        'nombre_producto', vi.nombre_producto,
        'precio_unitario', vi.precio_unitario,
        'cantidad',        vi.cantidad,
        'subtotal',        vi.subtotal
      ) order by vi.nombre_producto
    ) as items
  from public.ventas v
  join public.venta_items vi on vi.venta_id = v.id
  group by v.id
  order by v.created_at desc;
