import React, { useEffect, useRef } from 'react';
import { Animated, Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import { Colors, Radius } from '@/lib/theme';

type ToastType = 'success' | 'error' | 'warning';

interface ToastProps {
  visible: boolean;
  type: ToastType;
  title: string;
  subtitle?: string;
  onDismiss: () => void;
}

const BG: Record<ToastType, string> = {
  success: 'rgba(6,214,160,0.95)',
  error: 'rgba(233,69,96,0.95)',
  warning: 'rgba(180,130,0,0.92)',
};

const ICON: Record<ToastType, string> = {
  success: '✅',
  error: '❌',
  warning: '⚠️',
};

export function Toast({ visible, type, title, subtitle, onDismiss }: ToastProps) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.spring(anim, { toValue: 1, useNativeDriver: true, tension: 80 }).start();
      const t = setTimeout(onDismiss, 3000);
      return () => clearTimeout(t);
    } else {
      Animated.timing(anim, { toValue: 0, duration: 200, useNativeDriver: true }).start();
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <Animated.View style={[
      styles.toast,
      { backgroundColor: BG[type], opacity: anim, transform: [{ translateY: anim.interpolate({ inputRange: [0,1], outputRange: [-20, 0] }) }] }
    ]}>
      <Text style={styles.icon}>{ICON[type]}</Text>
      <View style={styles.texts}>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      <TouchableOpacity onPress={onDismiss} hitSlop={12}>
        <Text style={styles.close}>✕</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  toast: {
    position: 'absolute', top: 16, left: 12, right: 12,
    borderRadius: Radius.md, padding: 10,
    flexDirection: 'row', alignItems: 'center', gap: 8, zIndex: 100,
  },
  icon: { fontSize: 16 },
  texts: { flex: 1 },
  title: { fontSize: 12, fontWeight: '700', color: '#fff' },
  subtitle: { fontSize: 10, color: 'rgba(255,255,255,0.8)', marginTop: 1 },
  close: { fontSize: 12, color: 'rgba(255,255,255,0.6)' },
});
