import React, { useState, useCallback } from 'react';
import {
  Modal, View, Text, TouchableOpacity,
  StyleSheet, TouchableWithoutFeedback,
} from 'react-native';
import { Colors, Radius } from '@/lib/theme';

interface NumpadModalProps {
  visible: boolean;
  productoNombre: string;
  valorInicial: number;
  isDark: boolean;
  onConfirm: (value: number) => void;
  onClose: () => void;
}

const KEYS = ['1','2','3','4','5','6','7','8','00','0','⌫'];

export function NumpadModal({ visible, productoNombre, valorInicial, isDark, onConfirm, onClose }: NumpadModalProps) {
  const [input, setInput] = useState(String(valorInicial || ''));

  const handleKey = useCallback((key: string) => {
    if (key === '⌫') {
      setInput(p => p.slice(0, -1));
      return;
    }
    setInput(p => {
      const next = p + key;
      // Máximo 4 dígitos y <= 9999
      if (next.length > 4) return p;
      if (parseInt(next, 10) > 9999) return p;
      return next;
    });
  }, []);

  const handleConfirm = useCallback(() => {
    const val = parseInt(input, 10);
    onConfirm(isNaN(val) ? 0 : Math.max(0, val));
    onClose();
  }, [input, onConfirm, onClose]);

  const bg = isDark ? Colors.cardDark2 : Colors.surfaceLight;
  const keyBg = isDark ? Colors.inputDark : '#F0F0FA';
  const keyColor = isDark ? Colors.textDark : Colors.textLight;
  const displayBg = isDark ? Colors.inputDark : '#F0F0FA';

  return (
    <Modal transparent visible={visible} animationType="slide" onRequestClose={onClose}>
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.overlay} />
      </TouchableWithoutFeedback>
      <View style={[styles.sheet, { backgroundColor: bg }]}>
        <View style={[styles.handle, { backgroundColor: isDark ? 'rgba(255,255,255,0.1)' : '#E0E0EA' }]} />
        <Text style={[styles.nombre, { color: isDark ? Colors.textDark : Colors.textLight }]}>
          {productoNombre}
        </Text>
        <Text style={[styles.sub, { color: isDark ? Colors.textDark3 : Colors.textLight2 }]}>
          Ingresa la cantidad manualmente
        </Text>
        <View style={[styles.display, { backgroundColor: displayBg, borderColor: Colors.red }]}>
          <Text style={[styles.displayNum, { color: isDark ? Colors.textDark : Colors.textLight }]}>
            {input || '0'}
          </Text>
          <Text style={[styles.displayUnit, { color: isDark ? Colors.textDark3 : Colors.textLight2 }]}>
            unidades
          </Text>
        </View>
        <View style={styles.grid}>
          {KEYS.map((k) => (
            <TouchableOpacity
              key={k}
              style={[styles.key, { backgroundColor: keyBg }]}
              onPress={() => handleKey(k)}
              activeOpacity={0.7}
            >
              <Text style={[styles.keyText, { color: keyColor }]}>{k}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={styles.okBtn} onPress={handleConfirm} activeOpacity={0.85}>
          <Text style={styles.okText}>✅ Listo</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 16, paddingBottom: 28 },
  handle: { width: 32, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 14 },
  nombre: { fontSize: 14, fontWeight: '800', marginBottom: 2 },
  sub: { fontSize: 11, marginBottom: 10 },
  display: {
    borderWidth: 2, borderRadius: Radius.md,
    padding: 12, alignItems: 'center', marginBottom: 10,
  },
  displayNum: { fontSize: 32, fontWeight: '800' },
  displayUnit: { fontSize: 10 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  key: {
    width: '30%', paddingVertical: 10, borderRadius: Radius.sm,
    alignItems: 'center', justifyContent: 'center',
  },
  keyText: { fontSize: 16, fontWeight: '700' },
  okBtn: {
    backgroundColor: Colors.red,
    borderRadius: Radius.md,
    padding: 13,
    alignItems: 'center',
  },
  okText: { color: '#fff', fontSize: 13, fontWeight: '700' },
});
