// import React, { createContext, useContext, ReactNode } from 'react';
// import { useTheme } from '@/hooks/useTheme';
// import { useMoneda, Moneda } from '@/hooks/useMoneda';

// interface ThemeContextType {
//   isDark: boolean;
//   toggle: () => void;
//   moneda: Moneda;
//   simbolo: string;
//   cambiarMoneda: (m: Moneda) => void;
// }

// const ThemeContext = createContext<ThemeContextType | null>(null);

// export function ThemeProvider({ children }: { children: ReactNode }) {
//   const { isDark, toggle } = useTheme();
//   const { moneda, simbolo, cambiarMoneda } = useMoneda();

//   return (
//     <ThemeContext.Provider value={{ isDark, toggle, moneda, simbolo, cambiarMoneda }}>
//       {children}
//     </ThemeContext.Provider>
//   );
// }

// export function useThemeContext() {
//   const ctx = useContext(ThemeContext);
//   if (!ctx) throw new Error('useThemeContext must be used within ThemeProvider');
//   return ctx;
// }



















import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { useColorScheme, Platform, StatusBar } from 'react-native';
// Asegúrate de tener AsyncStorage instalado (npm install @react-native-async-storage/async-storage)
import AsyncStorage from '@react-native-async-storage/async-storage';

type ThemeContextType = {
  isDark: boolean;
  toggleTheme: () => void;
  simbolo: string; // '$' o 'S/.'
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = '@app_theme_mode';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const deviceColorScheme = useColorScheme(); // 'light' o 'dark'
  
  // Iniciamos con el tema del dispositivo como respaldo
  const [isDark, setIsDark] = useState(deviceColorScheme === 'dark');

  // Cargar el tema guardado al iniciar la app
  useEffect(() => {
    const loadSavedTheme = async () => {
      try {
        const savedTheme = await AsyncStorage.getItem(THEME_STORAGE_KEY);
        if (savedTheme !== null) {
          setIsDark(savedTheme === 'dark');
        } else {
          // Si no hay guardado, usa el del dispositivo
          setIsDark(deviceColorScheme === 'dark');
        }
      } catch (e) {
        // En web o error, usar dispositivo como fallback
        setIsDark(deviceColorScheme === 'dark');
      }
    };
    loadSavedTheme();
  }, [deviceColorScheme]);

  // Actualizar la Barra de Estado (StatusBar) reactivamente
  useEffect(() => {
    if (Platform.OS !== 'web') {
      StatusBar.setBarStyle(isDark ? 'light-content' : 'dark-content', true);
      // Opcional: ajustar el color de fondo de la StatusBar en Android
      if (Platform.OS === 'android') {
        StatusBar.setBackgroundColor(isDark ? '#07070F' : '#FFFFFF', true);
      }
    }
  }, [isDark]);

  const toggleTheme = useCallback(async () => {
    setIsDark((prev) => {
      const nextMode = !prev;
      // Guardar la nueva preferencia asíncronamente
      AsyncStorage.setItem(THEME_STORAGE_KEY, nextMode ? 'dark' : 'light').catch(() => {
        // Fallback silencioso si AsyncStorage falla (ej. en web Safari privada)
      });
      return nextMode;
    });
  }, []);

  // Memorizamos 'simbolo' para que no recalcule innecesariamente
  const simbolo = useMemo(() => '$', []);

  // Memorizamos el valor del contexto para evitar renderizados extras en los hijos
  const value = useMemo(() => ({
    isDark,
    toggleTheme,
    simbolo,
  }), [isDark, toggleTheme, simbolo]);

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useThemeContext = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useThemeContext debe usarse dentro de un ThemeProvider');
  }
  return context;
};
