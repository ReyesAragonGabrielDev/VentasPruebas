// import React, { useState } from 'react';
// import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
// import { NumpadModal } from './NumpadModal';
// import type { Producto } from '@/types/database';

// interface ProductoCardProps {
//   producto: Producto;
//   cantidad: number;
//   simbolo: string;
//   isDark: boolean;
//   onCantidadChange: (productoId: string, cantidad: number) => void;
//   onEdit?: (producto: Producto) => void;
//   onDelete?: (id: string) => void;
// }

// // Color rojo activo (el mismo de tu botón enviar)
// const COLOR_ROJO_ACTIVO = '#E94560';

// export function ProductoCard({ 
//   producto, cantidad, simbolo, isDark, onCantidadChange, onEdit, onDelete 
// }: ProductoCardProps) {
//   const [numpadVisible, setNumpadVisible] = useState(false);

//   const cardBg = isDark ? '#1C1C2E' : '#FFFFFF';
//   const textColor = isDark ? '#F0F0FF' : '#1A1A2E';
//   const borderColor = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.06)';

//   return (
//     <View style={[styles.card, { backgroundColor: cardBg, borderColor: borderColor }]}>
      
//       {/* Botón Reset individual */}
//       {cantidad > 0 && (
//         <TouchableOpacity 
//           style={styles.pcRst} 
//           onPress={() => onCantidadChange(producto.id, 0)}
//         >
//           <Text style={styles.pcRstText}>↺</Text>
//         </TouchableOpacity>
//       )}

//       <Text style={[styles.nombre, { color: textColor }]}>{producto.nombre}</Text>
//       <Text style={styles.precio}>{simbolo}{producto.precio.toFixed(2)}</Text>

//       {/* Contador (Abre el Numpad) */}
//       <TouchableOpacity 
//         style={[styles.pcQty, { borderColor: cantidad > 0 ? COLOR_ROJO_ACTIVO : borderColor }]}
//         onPress={() => setNumpadVisible(true)}
//       >
//         <Text style={[styles.pcQn, { color: cantidad > 0 ? COLOR_ROJO_ACTIVO : textColor }]}>
//           {cantidad}
//         </Text>
//       </TouchableOpacity>

//       <View style={styles.pcBtns}>
//         {/* Botón Menos */}
//         <TouchableOpacity 
//           style={styles.pcMinus} 
//           onPress={() => onCantidadChange(producto.id, Math.max(0, cantidad - 1))}
//         >
//           <Text style={[styles.btnText, { color: textColor }]}>−</Text>
//         </TouchableOpacity>

//         {/* Botón Más (Círculo rojo con "+" blanco) */}
//         <TouchableOpacity 
//           style={styles.pcPlusCircular} 
//           onPress={() => onCantidadChange(producto.id, cantidad + 1)}
//         >
//           <Image 
//             source={require('@/assets/masB.png')} 
//             style={styles.imagenMasBlanca} 
//           />
//         </TouchableOpacity>
//       </View>

//       {/* Acciones de Administración */}
//       <View style={styles.adminActions}>
//         {onEdit && (
//           <TouchableOpacity onPress={() => onEdit(producto)} style={styles.piE}>
//             <Image source={require('@/assets/edit.png')} style={styles.iconImg} />
//           </TouchableOpacity>
//         )}
//         {onDelete && (
//           <TouchableOpacity onPress={() => onDelete(producto.id)} style={styles.piD}>
//             <Image source={require('@/assets/trash.png')} style={styles.iconImg} />
//           </TouchableOpacity>
//         )}
//       </View>

//       <NumpadModal
//         visible={numpadVisible}
//         productoNombre={producto.nombre}
//         valorInicial={cantidad}
//         isDark={isDark}
//         onConfirm={(val) => onCantidadChange(producto.id, val)}
//         onClose={() => setNumpadVisible(false)}
//       />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   card: {
//     borderRadius: 14,
//     padding: 12,
//     margin: 5,
//     alignItems: 'center',
//     borderWidth: 1,
//     minWidth: 140,
//     flex: 1,
//   },
//   pcRst: {
//     position: 'absolute', top: 6, right: 6,
//     width: 20, height: 20, borderRadius: 10,
//     backgroundColor: 'rgba(255,255,255,0.07)',
//     alignItems: 'center', justifyContent: 'center',
//   },
//   pcRstText: { fontSize: 10, color: 'rgba(255,255,255,0.4)' },
//   nombre: { fontSize: 12, fontWeight: '800', textAlign: 'center', marginBottom: 2 },
//   precio: { fontSize: 11, fontWeight: '700', color: COLOR_ROJO_ACTIVO, marginBottom: 8 },
//   pcQty: {
//     width: 58, height: 28, borderRadius: 14,
//     borderWidth: 1.5, alignItems: 'center', justifyContent: 'center',
//     marginBottom: 8, backgroundColor: 'rgba(255,255,255,0.03)',
//   },
//   pcQn: { fontSize: 15, fontWeight: '800' },
//   pcBtns: { 
//     flexDirection: 'row', 
//     gap: 14, 
//     alignItems: 'center',
//     marginTop: 4
//   },
//   pcMinus: {
//     width: 36,
//     height: 36,
//     borderRadius: 18,
//     borderWidth: 1.5,
//     borderColor: 'rgba(255,255,255,0.1)',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   pcPlusCircular: {
//     width: 44,
//     height: 44,
//     borderRadius: 22,
//     backgroundColor: COLOR_ROJO_ACTIVO,
//     alignItems: 'center',
//     justifyContent: 'center',
//     elevation: 3,
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 2 },
//     shadowOpacity: 0.2,
//     shadowRadius: 2,
//   },
//   imagenMasBlanca: { 
//     width: '65%', // Ajustado para que el + se vea grande pero no toque los bordes
//     height: '65%', 
//     resizeMode: 'contain',
//     tintColor: '#FFFFFF', // Esto vuelve blanca la imagen negra
//   },
//   btnText: { fontSize: 22, fontWeight: '400' }, // Estilo para el símbolo menos
//   adminActions: { flexDirection: 'row', gap: 10, marginTop: 12 },
//   iconImg: { width: 18, height: 18, resizeMode: 'contain' },
//   piE: { padding: 6, backgroundColor: 'rgba(79,195,247,0.1)', borderRadius: 8 },
//   piD: { padding: 6, backgroundColor: 'rgba(233,69,96,0.1)', borderRadius: 8 },
// });

















































// ultimo que comente
// import React, { useState } from 'react';
// import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
// import { NumpadModal } from './NumpadModal';
// import type { Producto } from '@/types/database';

// interface ProductoCardProps {
//   producto: Producto;
//   cantidad: number;
//   simbolo: string;
//   isDark: boolean;
//   onCantidadChange: (productoId: string, cantidad: number) => void;
//   onEdit?: (producto: Producto) => void;
//   onDelete?: (id: string) => void;
// }

// const COLOR_ROJO_ACTIVO = '#E94560';

// export function ProductoCard({ 
//   producto, cantidad, simbolo, isDark, onCantidadChange, onEdit, onDelete 
// }: ProductoCardProps) {
//   const [numpadVisible, setNumpadVisible] = useState(false);

//   const cardBg = isDark ? '#1C1C2E' : '#FFFFFF';
//   const textColor = isDark ? '#F0F0FF' : '#1A1A2E';
//   const borderColor = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.06)';

//   return (
//     <View style={[styles.card, { backgroundColor: cardBg, borderColor: borderColor }]}>
      
//       {cantidad > 0 && (
//         <TouchableOpacity 
//           style={styles.pcRst} 
//           onPress={() => onCantidadChange(producto.id, 0)}
//         >
//           <Text style={styles.pcRstText}>↺</Text>
//         </TouchableOpacity>
//       )}

//       <Text style={[styles.nombre, { color: textColor }]}>{producto.nombre}</Text>
//       <Text style={styles.precio}>{simbolo}{producto.precio.toFixed(2)}</Text>

//       <TouchableOpacity 
//         style={[styles.pcQty, { borderColor: cantidad > 0 ? COLOR_ROJO_ACTIVO : borderColor }]}
//         onPress={() => setNumpadVisible(true)}
//       >
//         <Text style={[styles.pcQn, { color: cantidad > 0 ? COLOR_ROJO_ACTIVO : textColor }]}>
//           {cantidad}
//         </Text>
//       </TouchableOpacity>

//       <View style={styles.pcBtns}>
//         {/* Botón Menos - AHORA CON IMAGEN Y CÍRCULO */}
//         <TouchableOpacity 
//           style={[styles.pcMinusCircular, { borderColor: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.1)' }]} 
//           onPress={() => onCantidadChange(producto.id, Math.max(0, cantidad - 1))}
//         >
//           <Image 
//             source={require('@/assets/menos.png')} 
//             style={[styles.imagenIcono, { tintColor: textColor }]} 
//           />
//         </TouchableOpacity>

//         {/* Botón Más - Círculo rojo con "+" blanco */}
//         <TouchableOpacity 
//           style={styles.pcPlusCircular} 
//           onPress={() => onCantidadChange(producto.id, cantidad + 1)}
//         >
//           <Image 
//             source={require('@/assets/mas.png')} 
//             style={[styles.imagenIcono, { tintColor: '#FFFFFF' }]} 
//           />
//         </TouchableOpacity>
//       </View>

//       <View style={styles.adminActions}>
//         {onEdit && (
//           <TouchableOpacity onPress={() => onEdit(producto)} style={styles.piE}>
//             <Image source={require('@/assets/edit.png')} style={styles.iconImg} />
//           </TouchableOpacity>
//         )}
//         {onDelete && (
//           <TouchableOpacity onPress={() => onDelete(producto.id)} style={styles.piD}>
//             <Image source={require('@/assets/trash.png')} style={styles.iconImg} />
//           </TouchableOpacity>
//         )}
//       </View>

//       <NumpadModal
//         visible={numpadVisible}
//         productoNombre={producto.nombre}
//         valorInicial={cantidad}
//         isDark={isDark}
//         onConfirm={(val) => onCantidadChange(producto.id, val)}
//         onClose={() => setNumpadVisible(false)}
//       />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   card: {
//     borderRadius: 14, padding: 12, margin: 5,
//     alignItems: 'center', borderWidth: 1, minWidth: 140, flex: 1,
//   },
//   pcRst: {
//     position: 'absolute', top: 6, right: 6,
//     width: 20, height: 20, borderRadius: 10,
//     backgroundColor: 'rgba(255,255,255,0.07)',
//     alignItems: 'center', justifyContent: 'center',
//   },
//   pcRstText: { fontSize: 10, color: 'rgba(255,255,255,0.4)' },
//   nombre: { fontSize: 12, fontWeight: '800', textAlign: 'center', marginBottom: 2 },
//   precio: { fontSize: 11, fontWeight: '700', color: COLOR_ROJO_ACTIVO, marginBottom: 8 },
//   pcQty: {
//     width: 58, height: 28, borderRadius: 14,
//     borderWidth: 1.5, alignItems: 'center', justifyContent: 'center',
//     marginBottom: 8, backgroundColor: 'rgba(255,255,255,0.03)',
//   },
//   pcQn: { fontSize: 15, fontWeight: '800' },
//   pcBtns: { 
//     flexDirection: 'row', 
//     gap: 16, 
//     alignItems: 'center',
//     marginTop: 4
//   },
//   // Estilo para el círculo del botón MENOS
//   pcMinusCircular: {
//     width: 38,
//     height: 38,
//     borderRadius: 19,
//     borderWidth: 1.5,
//     alignItems: 'center',
//     justifyContent: 'center',
//     backgroundColor: 'rgba(255,255,255,0.05)',
//   },
//   // Estilo para el círculo del botón MÁS
//   pcPlusCircular: {
//     width: 42,
//     height: 42,
//     borderRadius: 21,
//     backgroundColor: COLOR_ROJO_ACTIVO,
//     alignItems: 'center',
//     justifyContent: 'center',
//     elevation: 3,
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 2 },
//     shadowOpacity: 0.2,
//     shadowRadius: 2,
//   },
//   // Estilo compartido para las imágenes de los iconos
//   imagenIcono: { 
//     width: '55%', 
//     height: '55%', 
//     resizeMode: 'contain',
//   },
//   adminActions: { flexDirection: 'row', gap: 10, marginTop: 12 },
//   iconImg: { width: 18, height: 18, resizeMode: 'contain' },
//   piE: { padding: 6, backgroundColor: 'rgba(79,195,247,0.1)', borderRadius: 8 },
//   piD: { padding: 6, backgroundColor: 'rgba(233,69,96,0.1)', borderRadius: 8 },
// });
















































import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { NumpadModal } from './NumpadModal';
import type { Producto } from '@/types/database';

interface ProductoCardProps {
  producto: Producto;
  cantidad: number;
  simbolo: string;
  isDark: boolean;
  onCantidadChange: (productoId: string, cantidad: number) => void;
  onEdit?: (producto: Producto) => void;
  onDelete?: (id: string) => void;
}

const COLOR_ROJO_ACTIVO = '#E94560';

export function ProductoCard({ 
  producto, cantidad, simbolo, isDark, onCantidadChange, onEdit, onDelete 
}: ProductoCardProps) {
  const [numpadVisible, setNumpadVisible] = useState(false);

  const cardBg = isDark ? '#1C1C2E' : '#FFFFFF';
  const textColor = isDark ? '#F0F0FF' : '#1A1A2E';
  const borderColor = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.06)';

  return (
    <View style={[styles.card, { backgroundColor: cardBg, borderColor: borderColor }]}>
      
      {/* Botón Reset individual */}
      {cantidad > 0 && (
        <TouchableOpacity 
          style={styles.pcRst} 
          onPress={() => onCantidadChange(producto.id, 0)}
        >
          <Text style={styles.pcRstText}>↺</Text>
        </TouchableOpacity>
      )}

      <Text style={[styles.nombre, { color: textColor }]}>{producto.nombre}</Text>
      <Text style={styles.precio}>{simbolo}{producto.precio.toFixed(2)}</Text>

      {/* Contador (Abre el Numpad) */}
      <TouchableOpacity 
        style={[styles.pcQty, { borderColor: cantidad > 0 ? COLOR_ROJO_ACTIVO : borderColor }]}
        onPress={() => setNumpadVisible(true)}
      >
        <Text style={[styles.pcQn, { color: cantidad > 0 ? COLOR_ROJO_ACTIVO : textColor }]}>
          {cantidad}
        </Text>
      </TouchableOpacity>

      <View style={styles.pcBtns}>
        {/* Botón Menos */}
        <TouchableOpacity 
          style={[styles.pcMinusCircular, { borderColor: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.1)' }]} 
          onPress={() => onCantidadChange(producto.id, Math.max(0, cantidad - 1))}
        >
          <Image 
            source={require('@/assets/menos.png')} 
            style={[styles.imagenIcono, { tintColor: textColor }]} 
          />
        </TouchableOpacity>

        {/* Botón Más */}
        <TouchableOpacity 
          style={styles.pcPlusCircular} 
          onPress={() => onCantidadChange(producto.id, cantidad + 1)}
        >
          <Image 
            source={require('@/assets/mas.png')} 
            style={[styles.imagenIcono, { tintColor: '#FFFFFF' }]} 
          />
        </TouchableOpacity>
      </View>

      {/* Acciones de Administración */}
      <View style={styles.adminActions}>
        {onEdit && (
          <TouchableOpacity onPress={() => onEdit(producto)} style={styles.piE}>
            <Image source={require('@/assets/edit.png')} style={styles.iconImg} />
          </TouchableOpacity>
        )}
        {onDelete && (
          <TouchableOpacity onPress={() => onDelete(producto.id)} style={styles.piD}>
            <Image source={require('@/assets/trash.png')} style={styles.iconImg} />
          </TouchableOpacity>
        )}
      </View>

      <NumpadModal
        visible={numpadVisible}
        productoNombre={producto.nombre}
        valorInicial={cantidad}
        isDark={isDark}
        onConfirm={(val) => onCantidadChange(producto.id, val)}
        onClose={() => setNumpadVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 14, padding: 12, margin: 5,
    alignItems: 'center', borderWidth: 1, minWidth: 140, flex: 1,
  },
  pcRst: {
    position: 'absolute', top: 6, right: 6,
    width: 20, height: 20, borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.07)',
    alignItems: 'center', justifyContent: 'center',
  },
  pcRstText: { fontSize: 10, color: 'rgba(255,255,255,0.4)' },
  nombre: { fontSize: 12, fontWeight: '800', textAlign: 'center', marginBottom: 2 },
  precio: { fontSize: 11, fontWeight: '700', color: COLOR_ROJO_ACTIVO, marginBottom: 8 },
  pcQty: {
    width: 58, height: 28, borderRadius: 14,
    borderWidth: 1.5, alignItems: 'center', justifyContent: 'center',
    marginBottom: 8, backgroundColor: 'rgba(255,255,255,0.03)',
  },
  pcQn: { fontSize: 15, fontWeight: '800' },
  pcBtns: { flexDirection: 'row', gap: 16, alignItems: 'center', marginTop: 4 },
  pcMinusCircular: {
    width: 38, height: 38, borderRadius: 19, borderWidth: 1.5,
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  pcPlusCircular: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: COLOR_ROJO_ACTIVO,
    alignItems: 'center', justifyContent: 'center',
    elevation: 3, shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2, shadowRadius: 2,
  },
  imagenIcono: { width: '55%', height: '55%', resizeMode: 'contain' },
  adminActions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  iconImg: { width: 18, height: 18, resizeMode: 'contain' },
  piE: { padding: 6, backgroundColor: 'rgba(79,195,247,0.1)', borderRadius: 8 },
  piD: { padding: 6, backgroundColor: 'rgba(233,69,96,0.1)', borderRadius: 8 },
});
