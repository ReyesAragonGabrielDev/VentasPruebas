// // Tipos que reflejan exactamente el esquema de Supabase.
// // Si cambias el SQL, actualiza estos tipos también.

// export interface Database {
//   public: {
//     Tables: {
//       productos: {
//         Row: Producto;
//         Insert: ProductoInsert;
//         Update: ProductoUpdate;
//       };
//       ventas: {
//         Row: Venta;
//         Insert: VentaInsert;
//         Update: never; // Las ventas no se editan
//       };
//       venta_items: {
//         Row: VentaItem;
//         Insert: VentaItemInsert;
//         Update: never;
//       };
//     };
//   };
// }

// // ─── Producto ────────────────────────────────────────────────────
// export interface Producto {
//   id: string;           // uuid
//   nombre: string;       // max 30 chars
//   precio: number;       // > 0, numeric(10,2)
//   descripcion: string | null; // max 60 chars
//   activo: boolean;
//   created_at: string;
//   updated_at: string;
// }

// export type ProductoInsert = Omit<Producto, 'id' | 'created_at' | 'updated_at' | 'activo'> & {
//   activo?: boolean;
// };

// export type ProductoUpdate = Partial<ProductoInsert>;

// // ─── Venta ───────────────────────────────────────────────────────
// export interface Venta {
//   id: string;           // uuid
//   total: number;        // suma de items
//   moneda: string;       // 'MXN', 'USD', etc.
//   latitud: number | null;
//   longitud: number | null;
//   created_at: string;
// }

// export type VentaInsert = Omit<Venta, 'id' | 'created_at'>;

// // ─── Venta Item ──────────────────────────────────────────────────
// export interface VentaItem {
//   id: string;
//   venta_id: string;
//   producto_id: string;
//   nombre_producto: string; // snapshot del nombre al momento de venta
//   precio_unitario: number; // snapshot del precio al momento de venta
//   cantidad: number;
//   subtotal: number;
// }

// export type VentaItemInsert = Omit<VentaItem, 'id'>;

















export interface Database {
  public: {
    Tables: {
      productos: {
        Row: Producto;
        Insert: ProductoInsert;
        Update: ProductoUpdate;
      };
      ventas: {
        Row: Venta;
        Insert: VentaInsert;
        Update: never; 
      };
      venta_items: {
        Row: VentaItem;
        Insert: VentaItemInsert;
        Update: never;
      };
    };
  };
}

export interface Producto {
  id: string;
  nombre: string;
  precio: number;
  descripcion: string | null;
  activo: boolean;
  created_at: string;
  updated_at: string;
}

export type ProductoInsert = Omit<Producto, 'id' | 'created_at' | 'updated_at' | 'activo'> & {
  activo?: boolean;
  descripcion?: string | null; // Ahora es opcional
};

export type ProductoUpdate = Partial<ProductoInsert>;

export interface Venta {
  id: string;
  total: number;
  moneda: string;
  latitud: number | null;
  longitud: number | null;
  created_at: string;
}

export type VentaInsert = Omit<Venta, 'id' | 'created_at'>;

export interface VentaItem {
  id: string;
  venta_id: string;
  producto_id: string;
  nombre_producto: string;
  precio_unitario: number;
  cantidad: number;
  subtotal: number;
}

export type VentaItemInsert = Omit<VentaItem, 'id'>;
