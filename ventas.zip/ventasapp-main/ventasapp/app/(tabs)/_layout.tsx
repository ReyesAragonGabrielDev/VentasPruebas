import React from 'react';
import { Tabs } from 'expo-router';
import { View, Text, StyleSheet, Image, Platform } from 'react-native';
import { useThemeContext } from '@/components/ThemeContext';

// Componente para los iconos de la barra
function TabIcon({ source, label, focused, isDark }: {
  source: any; label: string; focused: boolean; isDark: boolean;
}) {
  // Colores: Rojo para activo (#E94560), Gris tenue para inactivo
  const activeColor = '#E94560';
  const inactiveColor = isDark ? 'rgba(255,255,255,0.3)' : '#9090AA';
  const color = focused ? activeColor : inactiveColor;

  return (
    <View style={styles.tabContainer}>
      <Image 
        source={source} 
        style={[styles.iconImage, { tintColor: color }]} 
      />
      <Text style={[styles.tabLabel, { color }]}>{label}</Text>
    </View>
  );
}

export default function TabLayout() {
  const { isDark } = useThemeContext();
  
  // Fondo oscuro profundo como en tus imágenes de referencia
  const bg = isDark ? '#07070F' : '#FFFFFF';
  const border = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)';

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: bg,
          borderTopColor: border,
          borderTopWidth: 1,
          height: Platform.OS === 'ios' ? 88 : 65,
          paddingBottom: Platform.OS === 'ios' ? 30 : 10,
          paddingTop: 8,
          elevation: 0,
          shadowOpacity: 0,
        },
        tabBarShowLabel: false, // Ocultamos el label por defecto porque usamos el personalizado en TabIcon
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon 
              source={require('@/assets/inicio.png')} 
              label="Inicio" 
              focused={focused} 
              isDark={isDark} 
            />
          ),
        }}
      />
      <Tabs.Screen
        name="historial"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon 
              source={require('@/assets/history.png')} 
              label="Historial" 
              focused={focused} 
              isDark={isDark} 
            />
          ),
        }}
      />
      <Tabs.Screen
        name="config"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon 
              source={require('@/assets/ajustes.png')} 
              label="Configuración" 
              focused={focused} 
              isDark={isDark} 
            />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 100, // Espacio suficiente para que el texto no se corte
  },
  iconImage: {
    width: 22,
    height: 22,
    resizeMode: 'contain',
    marginBottom: 4,
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '600',
    // SE ELIMINÓ textTransform: 'uppercase' para permitir minúsculas
    letterSpacing: 0.2,
  },
});
