// import React, { useCallback, useState, useMemo } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity,
//   StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl,
//   Modal, Image, Dimensions, Platform, Alert
// } from 'react-native';
// import { useFocusEffect } from 'expo-router';
// import { useThemeContext } from '@/components/ThemeContext';
// import { useVentas } from '@/hooks/useVentas';
// import { useExportar } from '@/hooks/useExportar';
// import DatePicker from 'react-native-modern-datepicker';

// const { width: SCREEN_WIDTH } = Dimensions.get('window');

// export default function HistorialScreen() {
//   const { isDark, toggleTheme, simbolo } = useThemeContext();
//   const { ventas, loadingHistorial, cargarHistorial } = useVentas();
//   const { exportarPDF, exportarExcel } = useExportar();

//   const [filtro, setFiltro]           = useState<'Hoy' | 'Semana' | 'Mes' | 'Todo' | 'Custom'>('Hoy');
//   const [showCalendar, setShowCalendar] = useState(false);
//   const [exportandoPDF, setExportandoPDF]     = useState(false);
//   const [exportandoExcel, setExportandoExcel] = useState(false);

//   // ── Carga según filtro activo ────────────────────────────────────────────
//   const cargar = useCallback(() => {
//     const ahora  = new Date();
//     const hoy    = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate());

//     if (filtro === 'Hoy') {
//       cargarHistorial(hoy.toISOString());
//     } else if (filtro === 'Semana') {
//       const inicio = new Date(hoy);
//       inicio.setDate(hoy.getDate() - 7);
//       cargarHistorial(inicio.toISOString());
//     } else if (filtro === 'Mes') {
//       const inicio = new Date(hoy);
//       inicio.setDate(hoy.getDate() - 30);
//       cargarHistorial(inicio.toISOString());
//     } else {
//       cargarHistorial(); // Todo
//     }
//   }, [filtro, cargarHistorial]);

//   useFocusEffect(useCallback(() => { cargar(); }, [cargar]));

//   // ── Columnas dinámicas ──────────────────────────────────────────────────
//   const columnasProductos = useMemo(() => {
//     const nombres = new Set<string>();
//     ventas?.forEach(v => v.items?.forEach(i => { if (i.nombre_producto) nombres.add(i.nombre_producto); }));
//     return Array.from(nombres).sort();
//   }, [ventas]);

//   // ── Días con ventas para el calendario ─────────────────────────────────
//   const daysWithSales = useMemo(() =>
//     (ventas || []).map(v => v.created_at.slice(0, 10).replace(/-/g, '/')),
//   [ventas]);

//   // ── Exportar PDF ────────────────────────────────────────────────────────
//   const handleExportarPDF = useCallback(async () => {
//     setExportandoPDF(true);
//     const res = await exportarPDF(ventas, simbolo);
//     setExportandoPDF(false);
//     if (!res.ok) Alert.alert('Error', res.error ?? 'No se pudo exportar el PDF');
//   }, [ventas, simbolo, exportarPDF]);

//   // ── Exportar Excel ──────────────────────────────────────────────────────
//   const handleExportarExcel = useCallback(async () => {
//     setExportandoExcel(true);
//     const res = await exportarExcel(ventas, simbolo);
//     setExportandoExcel(false);
//     if (!res.ok) Alert.alert('Error', res.error ?? 'No se pudo exportar el Excel');
//   }, [ventas, simbolo, exportarExcel]);

//   // ── Colores ─────────────────────────────────────────────────────────────
//   const bg            = isDark ? '#07070F' : '#FFFFFF';
//   const textPrimary   = isDark ? '#FFFFFF' : '#1A1A2E';
//   const cardBg        = isDark ? '#161625' : '#F4F4FB';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
//   const tableHeaderBg = isDark ? '#1C1C2E' : '#E8E8F0';
//   const rowBorder     = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>

//       {/* CABECERA */}
//       <View style={styles.headerRow}>
//         <Text style={[styles.heroTitle, { color: textPrimary }]}>Historial</Text>
//         <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
//           <Image
//             source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')}
//             style={styles.themeIcon}
//             resizeMode="contain"
//           />
//         </TouchableOpacity>
//       </View>

//       <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

//       {/* FILTROS */}
//       <View style={styles.filterSection}>
//         <TouchableOpacity
//           style={[styles.calBtn, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }]}
//           onPress={() => setShowCalendar(true)}
//         >
//           <Text style={{ fontSize: 18 }}>📅</Text>
//         </TouchableOpacity>

//         {(['Hoy', 'Semana', 'Mes', 'Todo'] as const).map(f => (
//           <TouchableOpacity
//             key={f}
//             style={[styles.chip, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }, filtro === f && styles.chipActive]}
//             onPress={() => setFiltro(f)}
//           >
//             <Text style={[styles.chipText, filtro === f && styles.chipActiveText]}>{f}</Text>
//           </TouchableOpacity>
//         ))}
//       </View>

//       {/* TABLA */}
//       <View style={[styles.tableContainer, { backgroundColor: cardBg }]}>
//         <ScrollView horizontal showsHorizontalScrollIndicator={false}>
//           <View>
//             {/* Encabezados */}
//             <View style={[styles.tableHeader, { backgroundColor: tableHeaderBg }]}>
//               <Text style={styles.thFixed}>FECHA</Text>
//               <Text style={styles.thFixed}>HORA</Text>
//               <Text style={styles.thFixed}>UBIC.</Text>
//               {columnasProductos.map(nombre => (
//                 <Text key={nombre} style={styles.thDynamic}>{nombre.toUpperCase()}</Text>
//               ))}
//               <Text style={styles.thFixed}>TOTAL</Text>
//             </View>

//             {/* Filas */}
//             <ScrollView
//               style={{ maxHeight: 380 }}
//               refreshControl={
//                 <RefreshControl refreshing={loadingHistorial} onRefresh={cargar} tintColor="#E94560" />
//               }
//             >
//               {(!ventas || ventas.length === 0) ? (
//                 <View style={styles.emptyContainer}>
//                   <Text style={styles.emptyText}>Sin registros</Text>
//                 </View>
//               ) : (
//                 ventas.map(v => {
//                   const fechaObj = new Date(v.created_at);
//                   const coords = (v.latitud && v.longitud)
//                     ? `${v.latitud.toFixed(2)},${v.longitud.toFixed(2)}`
//                     : '---';
//                   return (
//                     <View key={v.id} style={[styles.tableRow, { borderBottomColor: rowBorder }]}>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>
//                         {fechaObj.toLocaleDateString([], { day: '2-digit', month: '2-digit' })}
//                       </Text>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>
//                         {fechaObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
//                       </Text>
//                       <Text style={[styles.tdFixed, { color: '#888', fontSize: 10 }]}>{coords}</Text>

//                       {columnasProductos.map(nombreCol => {
//                         const item = v.items?.find(i => i.nombre_producto === nombreCol);
//                         return (
//                           <Text
//                             key={nombreCol}
//                             style={[styles.tdDynamic, { color: item ? '#E94560' : '#444' }]}
//                           >
//                             {item ? item.cantidad : '-'}
//                           </Text>
//                         );
//                       })}

//                       <Text style={[styles.tdFixed, { color: '#E94560', fontWeight: '800' }]}>
//                         {simbolo}{Number(v.total).toFixed(2)}
//                       </Text>
//                     </View>
//                   );
//                 })
//               )}
//             </ScrollView>
//           </View>
//         </ScrollView>
//       </View>

//       {/* BOTONES EXPORTAR */}
//       <View style={styles.exportSection}>
//         <TouchableOpacity
//           style={[styles.exportBtn, { backgroundColor: '#E94560', opacity: exportandoPDF ? 0.7 : 1 }]}
//           onPress={handleExportarPDF}
//           disabled={exportandoPDF || ventas.length === 0}
//         >
//           {exportandoPDF
//             ? <ActivityIndicator color="#FFF" size="small" />
//             : <Text style={styles.exportText}>📄 EXPORTAR PDF</Text>}
//         </TouchableOpacity>

//         <TouchableOpacity
//           style={[styles.exportBtn, { backgroundColor: '#00D191', opacity: exportandoExcel ? 0.7 : 1 }]}
//           onPress={handleExportarExcel}
//           disabled={exportandoExcel || ventas.length === 0}
//         >
//           {exportandoExcel
//             ? <ActivityIndicator color="#FFF" size="small" />
//             : <Text style={styles.exportText}>📊 EXPORTAR EXCEL</Text>}
//         </TouchableOpacity>
//       </View>

//       {/* MODAL CALENDARIO */}
//       <Modal visible={showCalendar} transparent animationType="fade">
//         <View style={styles.modalOverlay}>
//           <View style={[styles.calendarBox, { backgroundColor: isDark ? '#1C1C2E' : '#FFF' }]}>
//             <DatePicker
//               mode="calendar"
//               isGregorian={true}
//               options={{
//                 backgroundColor: isDark ? '#1C1C2E' : '#FFF',
//                 textHeaderColor: '#E94560',
//                 textDefaultColor: isDark ? '#FFF' : '#000',
//                 selectedTextColor: '#FFF',
//                 mainColor: '#E94560',
//               }}
//               configs={{
//                 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
//                 dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
//                 monthNames: [
//                   'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
//                   'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
//                 ],
//               }}
//               days={daysWithSales}
//               onSelectedChange={() => { setFiltro('Custom'); setShowCalendar(false); }}
//             />
//             <TouchableOpacity onPress={() => setShowCalendar(false)} style={styles.closeBtn}>
//               <Text style={styles.closeBtnText}>CERRAR</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   headerRow: {
//     flexDirection: 'row', justifyContent: 'space-between',
//     alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10,
//   },
//   heroTitle: {
//     fontSize: 22, fontWeight: '900', letterSpacing: -0.2,
//     fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium',
//   },
//   themeIcon: { width: 28, height: 28 },
//   lineSeparator: { height: 2, width: '100%', marginBottom: 15 },
//   filterSection: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginBottom: 15 },
//   calBtn: { padding: 8, borderRadius: 12, justifyContent: 'center' },
//   chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, justifyContent: 'center' },
//   chipActive: { backgroundColor: '#E94560' },
//   chipText: { fontSize: 12, fontWeight: '700', color: '#666' },
//   chipActiveText: { color: '#FFF' },
//   tableContainer: { marginHorizontal: 15, borderRadius: 25, overflow: 'hidden', flex: 1, marginBottom: 10 },
//   tableHeader: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15 },
//   thFixed: { width: 80, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   thDynamic: { width: 95, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   tableRow: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15, borderBottomWidth: 1, alignItems: 'center' },
//   tdFixed: { width: 80, fontSize: 11, fontWeight: '600', textAlign: 'center' },
//   tdDynamic: { width: 95, fontSize: 12, fontWeight: '700', textAlign: 'center' },
//   emptyContainer: { padding: 40, alignItems: 'center', width: SCREEN_WIDTH },
//   emptyText: { color: '#555', fontWeight: '600' },
//   exportSection: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 20, paddingHorizontal: 20 },
//   exportBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', minHeight: 44 },
//   exportText: { color: '#FFF', fontWeight: '900', fontSize: 10 },
//   modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', padding: 20 },
//   calendarBox: { borderRadius: 30, padding: 20 },
//   closeBtn: { alignSelf: 'center', marginTop: 10, padding: 10 },
//   closeBtnText: { color: '#E94560', fontWeight: '900' },
// });































// import React, { useCallback, useState, useMemo } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity,
//   StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl,
//   Modal, Image, Dimensions, Platform
// } from 'react-native';
// import { useFocusEffect } from 'expo-router';
// import { useThemeContext } from '@/components/ThemeContext';
// import { useVentas } from '@/hooks/useVentas';
// import DatePicker from 'react-native-modern-datepicker';

// const { width: SCREEN_WIDTH } = Dimensions.get('window');

// export default function HistorialScreen() {
//   const { isDark, toggleTheme, simbolo } = useThemeContext();
//   const { ventas, loadingHistorial, cargarHistorial } = useVentas();
//   const [filtro, setFiltro] = useState<'Hoy' | 'Semana' | 'Mes' | 'Todo' | 'Custom'>('Hoy');
//   const [showCalendar, setShowCalendar] = useState(false);

//   // Recarga de datos al enfocar la pantalla
//   const cargar = useCallback(() => { cargarHistorial(); }, [cargarHistorial]);
//   useFocusEffect(useCallback(() => { cargar(); }, [cargar]));

//   // 1. GENERACIÓN DE COLUMNAS (Snapshot Histórico)
//   // Usamos encadenamiento opcional (?.) para evitar el error de 'undefined'
//   const columnasProductos = useMemo(() => {
//     const nombres = new Set<string>();
    
//     // Recorremos las ventas guardadas para extraer los nombres de productos que existieron
//     ventas?.forEach(v => {
//       v.items?.forEach(item => {
//         if (item.nombre_producto) {
//           nombres.add(item.nombre_producto);
//         }
//       });
//     });
    
//     return Array.from(nombres);
//   }, [ventas]);

//   // Fechas con ventas para marcar en el calendario
//   const daysWithSales = useMemo(() => {
//     return (ventas || []).map(v => v.created_at.slice(0, 10).replace(/-/g, '/'));
//   }, [ventas]);

//   // Colores del Tema
//   const bg = isDark ? '#07070F' : '#FFFFFF';
//   const textPrimary = isDark ? '#FFFFFF' : '#1A1A2E';
//   const cardBg = isDark ? '#161625' : '#F4F4FB';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
//   const tableHeaderBg = isDark ? '#1C1C2E' : '#E8E8F0';
//   const rowBorder = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
      
//       {/* CABECERA */}
//       <View style={styles.headerRow}>
//         <Text style={[styles.heroTitle, { color: textPrimary }]}>Historial</Text>
//         <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
//           <Image 
//             source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} 
//             style={styles.themeIcon} 
//             resizeMode="contain"
//           />
//         </TouchableOpacity>
//       </View>

//       <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

//       {/* FILTROS */}
//       <View style={styles.filterSection}>
//         <TouchableOpacity 
//           style={[styles.calBtn, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }]} 
//           onPress={() => setShowCalendar(true)}
//         >
//           <Text style={{ fontSize: 18 }}>📅</Text>
//         </TouchableOpacity>
        
//         {['Hoy', 'Semana', 'Mes', 'Todo'].map(f => (
//           <TouchableOpacity 
//             key={f} 
//             style={[
//               styles.chip, 
//               { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }, 
//               filtro === f && styles.chipActive
//             ]} 
//             onPress={() => setFiltro(f as any)}
//           >
//             <Text style={[styles.chipText, filtro === f && styles.chipActiveText]}>{f}</Text>
//           </TouchableOpacity>
//         ))}
//       </View>

//       {/* TABLA DE DATOS */}
//       <View style={[styles.tableContainer, { backgroundColor: cardBg }]}>
//         <ScrollView horizontal showsHorizontalScrollIndicator={false}>
//           <View>
//             {/* Encabezados */}
//             <View style={[styles.tableHeader, { backgroundColor: tableHeaderBg }]}>
//               <Text style={styles.thFixed}>FECHA</Text>
//               <Text style={styles.thFixed}>HORA</Text>
//               <Text style={styles.thFixed}>UBIC.</Text>
//               {columnasProductos.map(nombre => (
//                 <Text key={nombre} style={styles.thDynamic}>{nombre.toUpperCase()}</Text>
//               ))}
//               <Text style={styles.thFixed}>TOTAL</Text>
//             </View>

//             {/* Cuerpo de la tabla */}
//             <ScrollView 
//               style={{ maxHeight: 380 }}
//               refreshControl={
//                 <RefreshControl 
//                   refreshing={loadingHistorial} 
//                   onRefresh={cargar} 
//                   tintColor="#E94560" 
//                 />
//               }
//             >
//               {(!ventas || ventas.length === 0) ? (
//                 <View style={styles.emptyContainer}>
//                   <Text style={styles.emptyText}>Sin registros</Text>
//                 </View>
//               ) : (
//                 ventas.map(v => {
//                   const fechaObj = new Date(v.created_at);
//                   return (
//                     <View key={v.id} style={[styles.tableRow, { borderBottomColor: rowBorder }]}>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>
//                         {fechaObj.toLocaleDateString([], { day: '2-digit', month: '2-digit' })}
//                       </Text>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>
//                         {fechaObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
//                       </Text>
//                       <Text style={[styles.tdFixed, { color: '#888', fontSize: 10 }]}>
//                         {v.ubicacion || '---'}
//                       </Text>
                      
//                       {/* Celdas Dinámicas: Muestran la cantidad vendida en SU MOMENTO */}
//                       {columnasProductos.map(nombreCol => {
//                         const item = v.items?.find(i => i.nombre_producto === nombreCol);
//                         return (
//                           <Text 
//                             key={nombreCol} 
//                             style={[styles.tdDynamic, { color: item ? '#E94560' : '#444' }]}
//                           >
//                             {item ? item.cantidad : '-'}
//                           </Text>
//                         );
//                       })}
                      
//                       <Text style={[styles.tdFixed, { color: '#E94560', fontWeight: '800' }]}>
//                         {simbolo}{Number(v.total).toFixed(2)}
//                       </Text>
//                     </View>
//                   );
//                 })
//               )}
//             </ScrollView>
//           </View>
//         </ScrollView>
//       </View>

//       {/* BOTONES DE EXPORTACIÓN */}
//       <View style={styles.exportSection}>
//         <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#E94560' }]}>
//           <Text style={styles.exportText}>📄 EXPORTAR PDF</Text>
//         </TouchableOpacity>
//         <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#00D191' }]}>
//           <Text style={styles.exportText}>📊 EXPORTAR EXCEL</Text>
//         </TouchableOpacity>
//       </View>

//       {/* MODAL DEL CALENDARIO */}
//       <Modal visible={showCalendar} transparent animationType="fade">
//         <View style={styles.modalOverlay}>
//           <View style={[styles.calendarBox, { backgroundColor: isDark ? '#1C1C2E' : '#FFF' }]}>
//             <DatePicker 
//               mode="calendar"
//               isGregorian={true}
//               options={{
//                 backgroundColor: isDark ? '#1C1C2E' : '#FFF',
//                 textHeaderColor: '#E94560',
//                 textDefaultColor: isDark ? '#FFF' : '#000',
//                 selectedTextColor: '#FFF',
//                 mainColor: '#E94560',
//               }}
//               configs={{
//                 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
//                 dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
//                 monthNames: [
//                   'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
//                   'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
//                 ],
//               }}
//               days={daysWithSales}
//               onSelectedChange={() => setShowCalendar(false)}
//             />
//             <TouchableOpacity onPress={() => setShowCalendar(false)} style={styles.closeBtn}>
//               <Text style={styles.closeBtnText}>CERRAR</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   headerRow: { 
//     flexDirection: 'row', 
//     justifyContent: 'space-between', 
//     alignItems: 'center', 
//     paddingHorizontal: 25, 
//     paddingTop: 15, 
//     paddingBottom: 10 
//   },
//   heroTitle: { 
//     fontSize: 22, 
//     fontWeight: '900', 
//     letterSpacing: -0.2,
//     fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium'
//   },
//   themeIcon: { width: 28, height: 28 }, 
//   lineSeparator: { height: 2, width: '100%', marginBottom: 15 },
//   filterSection: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginBottom: 15 },
//   calBtn: { padding: 8, borderRadius: 12, justifyContent: 'center' },
//   chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, justifyContent: 'center' },
//   chipActive: { backgroundColor: '#E94560' },
//   chipText: { fontSize: 12, fontWeight: '700', color: '#666' },
//   chipActiveText: { color: '#FFF' },
//   tableContainer: { marginHorizontal: 15, borderRadius: 25, overflow: 'hidden', flex: 1, marginBottom: 10 },
//   tableHeader: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15 },
//   thFixed: { width: 80, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   thDynamic: { width: 95, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   tableRow: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15, borderBottomWidth: 1, alignItems: 'center' },
//   tdFixed: { width: 80, fontSize: 11, fontWeight: '600', textAlign: 'center' },
//   tdDynamic: { width: 95, fontSize: 12, fontWeight: '700', textAlign: 'center' },
//   emptyContainer: { padding: 40, alignItems: 'center', width: SCREEN_WIDTH },
//   emptyText: { color: '#555', fontWeight: '600' },
//   exportSection: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 20, paddingHorizontal: 20 },
//   exportBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
//   exportText: { color: '#FFF', fontWeight: '900', fontSize: 10 },
//   modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', padding: 20 },
//   calendarBox: { borderRadius: 30, padding: 20 },
//   closeBtn: { alignSelf: 'center', marginTop: 10, padding: 10 },
//   closeBtnText: { color: '#E94560', fontWeight: '900' }
// });








































// import React, { useCallback, useState, useMemo } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity,
//   StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl,
//   Modal, Image, Dimensions, Platform
// } from 'react-native';
// import { useFocusEffect } from 'expo-router';
// import { useThemeContext } from '@/components/ThemeContext';
// import { useVentas } from '@/hooks/useVentas';
// import DatePicker from 'react-native-modern-datepicker';

// const { width: SCREEN_WIDTH } = Dimensions.get('window');

// export default function HistorialScreen() {
//   const { isDark, toggleTheme, simbolo } = useThemeContext();
//   const { ventas, loadingHistorial, cargarHistorial } = useVentas();
//   const [filtro, setFiltro] = useState<'Hoy' | 'Semana' | 'Mes' | 'Todo' | 'Custom'>('Hoy');
//   const [showCalendar, setShowCalendar] = useState(false);

//   const cargar = useCallback(() => { cargarHistorial(); }, [cargarHistorial]);
//   useFocusEffect(useCallback(() => { cargar(); }, [cargar]));

//   const columnasProductos = useMemo(() => {
//     const nombres = new Set<string>();
//     ventas?.forEach(v => {
//       v.items?.forEach(item => {
//         if (item.nombre_producto) nombres.add(item.nombre_producto);
//       });
//     });
//     return Array.from(nombres);
//   }, [ventas]);

//   const daysWithSales = useMemo(() => {
//     return (ventas || []).map(v => v.created_at.slice(0, 10).replace(/-/g, '/'));
//   }, [ventas]);

//   const bg = isDark ? '#07070F' : '#FFFFFF';
//   const textPrimary = isDark ? '#FFFFFF' : '#1A1A2E';
//   const cardBg = isDark ? '#161625' : '#F4F4FB';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
//   const tableHeaderBg = isDark ? '#1C1C2E' : '#E8E8F0';
//   const rowBorder = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
//       <View style={styles.headerRow}>
//         <Text style={[styles.heroTitle, { color: textPrimary }]}>Historial</Text>
//         <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
//           <Image 
//             source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} 
//             style={styles.themeIcon} 
//             resizeMode="contain"
//           />
//         </TouchableOpacity>
//       </View>

//       <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

//       <View style={styles.filterSection}>
//         <TouchableOpacity 
//           style={[styles.calBtn, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }]} 
//           onPress={() => setShowCalendar(true)}
//         >
//           <Text style={{ fontSize: 18 }}>📅</Text>
//         </TouchableOpacity>
        
//         {['Hoy', 'Semana', 'Mes', 'Todo'].map(f => (
//           <TouchableOpacity 
//             key={f} 
//             style={[styles.chip, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }, filtro === f && styles.chipActive]} 
//             onPress={() => setFiltro(f as any)}
//           >
//             <Text style={[styles.chipText, filtro === f && styles.chipActiveText]}>{f}</Text>
//           </TouchableOpacity>
//         ))}
//       </View>

//       <View style={[styles.tableContainer, { backgroundColor: cardBg }]}>
//         <ScrollView horizontal showsHorizontalScrollIndicator={false}>
//           <View>
//             <View style={[styles.tableHeader, { backgroundColor: tableHeaderBg }]}>
//               <Text style={styles.thFixed}>FECHA</Text>
//               <Text style={styles.thFixed}>HORA</Text>
//               <Text style={styles.thUbicacion}>UBICACIÓN (LAT, LONG)</Text>
//               {columnasProductos.map(nombre => (
//                 <Text key={nombre} style={styles.thDynamic}>{nombre.toUpperCase()}</Text>
//               ))}
//               <Text style={styles.thFixed}>TOTAL</Text>
//             </View>

//             <ScrollView 
//               style={{ maxHeight: 380 }}
//               refreshControl={<RefreshControl refreshing={loadingHistorial} onRefresh={cargar} tintColor="#E94560" />}
//             >
//               {(!ventas || ventas.length === 0) ? (
//                 <View style={styles.emptyContainer}><Text style={styles.emptyText}>Sin registros</Text></View>
//               ) : (
//                 ventas.map(v => {
//                   const fechaObj = new Date(v.created_at);
//                   return (
//                     <View key={v.id} style={[styles.tableRow, { borderBottomColor: rowBorder }]}>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>
//                         {fechaObj.toLocaleDateString([], { day: '2-digit', month: '2-digit' })}
//                       </Text>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>
//                         {fechaObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
//                       </Text>
//                       <Text style={[styles.tdUbicacion, { color: '#888' }]}>
//                         {v.ubicacion || 'Sin GPS'}
//                       </Text>
                      
//                       {columnasProductos.map(nombreCol => {
//                         const item = v.items?.find(i => i.nombre_producto === nombreCol);
//                         return (
//                           <Text key={nombreCol} style={[styles.tdDynamic, { color: item ? '#E94560' : '#444' }]}>
//                             {item ? item.cantidad : '-'}
//                           </Text>
//                         );
//                       })}
                      
//                       <Text style={[styles.tdFixed, { color: '#E94560', fontWeight: '800' }]}>
//                         {simbolo}{Number(v.total).toFixed(2)}
//                       </Text>
//                     </View>
//                   );
//                 })
//               )}
//             </ScrollView>
//           </View>
//         </ScrollView>
//       </View>

//       <View style={styles.exportSection}>
//         <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#E94560' }]}><Text style={styles.exportText}>📄 EXPORTAR PDF</Text></TouchableOpacity>
//         <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#00D191' }]}><Text style={styles.exportText}>📊 EXPORTAR EXCEL</Text></TouchableOpacity>
//       </View>

//       <Modal visible={showCalendar} transparent animationType="fade">
//         <View style={styles.modalOverlay}>
//           <View style={[styles.calendarBox, { backgroundColor: isDark ? '#1C1C2E' : '#FFF' }]}>
//             <DatePicker 
//               mode="calendar"
//               isGregorian={true}
//               options={{
//                 backgroundColor: isDark ? '#1C1C2E' : '#FFF',
//                 textHeaderColor: '#E94560',
//                 textDefaultColor: isDark ? '#FFF' : '#000',
//                 selectedTextColor: '#FFF',
//                 mainColor: '#E94560',
//               }}
//               configs={{
//                 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
//                 dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
//                 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
//               }}
//               days={daysWithSales}
//               onSelectedChange={() => setShowCalendar(false)}
//             />
//             <TouchableOpacity onPress={() => setShowCalendar(false)} style={styles.closeBtn}><Text style={styles.closeBtnText}>CERRAR</Text></TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10 },
//   heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2, fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium' },
//   themeIcon: { width: 28, height: 28 }, 
//   lineSeparator: { height: 2, width: '100%', marginBottom: 15 },
//   filterSection: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginBottom: 15 },
//   calBtn: { padding: 8, borderRadius: 12, justifyContent: 'center' },
//   chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, justifyContent: 'center' },
//   chipActive: { backgroundColor: '#E94560' },
//   chipText: { fontSize: 12, fontWeight: '700', color: '#666' },
//   chipActiveText: { color: '#FFF' },
//   tableContainer: { marginHorizontal: 15, borderRadius: 25, overflow: 'hidden', flex: 1, marginBottom: 10 },
//   tableHeader: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15 },
//   thFixed: { width: 80, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   thUbicacion: { width: 110, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' }, // Ancho aumentado
//   thDynamic: { width: 95, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   tableRow: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15, borderBottomWidth: 1, alignItems: 'center' },
//   tdFixed: { width: 80, fontSize: 11, fontWeight: '600', textAlign: 'center' },
//   tdUbicacion: { width: 110, fontSize: 10, fontWeight: '600', textAlign: 'center' }, // Ancho aumentado y letra ajustada
//   tdDynamic: { width: 95, fontSize: 12, fontWeight: '700', textAlign: 'center' },
//   emptyContainer: { padding: 40, alignItems: 'center', width: SCREEN_WIDTH },
//   emptyText: { color: '#555', fontWeight: '600' },
//   exportSection: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 20, paddingHorizontal: 20 },
//   exportBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
//   exportText: { color: '#FFF', fontWeight: '900', fontSize: 10 },
//   modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', padding: 20 },
//   calendarBox: { borderRadius: 30, padding: 20 },
//   closeBtn: { alignSelf: 'center', marginTop: 10, padding: 10 },
//   closeBtnText: { color: '#E94560', fontWeight: '900' }
// });







































// import React, { useCallback, useState, useMemo } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity,
//   StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl,
//   Modal, Image, Dimensions, Platform
// } from 'react-native';
// import { useFocusEffect } from 'expo-router';
// import { useThemeContext } from '@/components/ThemeContext';
// import { useVentas } from '@/hooks/useVentas';
// import DatePicker from 'react-native-modern-datepicker';

// const { width: SCREEN_WIDTH } = Dimensions.get('window');

// export default function HistorialScreen() {
//   const { isDark, toggleTheme, simbolo } = useThemeContext();
//   const { ventas, loadingHistorial, cargarHistorial } = useVentas();
//   const [filtro, setFiltro] = useState<'Hoy' | 'Semana' | 'Mes' | 'Todo' | 'Custom'>('Hoy');
//   const [showCalendar, setShowCalendar] = useState(false);

//   const cargar = useCallback(() => { cargarHistorial(); }, [cargarHistorial]);
//   useFocusEffect(useCallback(() => { cargar(); }, [cargar]));

//   const columnasProductos = useMemo(() => {
//     const nombres = new Set<string>();
//     if (!ventas) return [];
//     ventas.forEach(v => {
//       v.items?.forEach(item => {
//         if (item.nombre_producto) nombres.add(item.nombre_producto);
//       });
//     });
//     return Array.from(nombres);
//   }, [ventas]);

//   const daysWithSales = useMemo(() => {
//     return (ventas || []).map(v => v.created_at.slice(0, 10).replace(/-/g, '/'));
//   }, [ventas]);

//   const bg = isDark ? '#07070F' : '#FFFFFF';
//   const textPrimary = isDark ? '#FFFFFF' : '#1A1A2E';
//   const cardBg = isDark ? '#161625' : '#F4F4FB';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
//   const tableHeaderBg = isDark ? '#1C1C2E' : '#E8E8F0';
//   const rowBorder = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
//       <View style={styles.headerRow}>
//         <Text style={[styles.heroTitle, { color: textPrimary }]}>Historial</Text>
//         <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
//           <Image source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} style={styles.themeIcon} resizeMode="contain" />
//         </TouchableOpacity>
//       </View>

//       <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

//       <View style={styles.filterSection}>
//         <TouchableOpacity style={[styles.calBtn, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }]} onPress={() => setShowCalendar(true)}>
//           <Text style={{ fontSize: 18 }}>📅</Text>
//         </TouchableOpacity>
//         {['Hoy', 'Semana', 'Mes', 'Todo'].map(f => (
//           <TouchableOpacity key={f} style={[styles.chip, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }, filtro === f && styles.chipActive]} onPress={() => setFiltro(f as any)}>
//             <Text style={[styles.chipText, filtro === f && styles.chipActiveText]}>{f}</Text>
//           </TouchableOpacity>
//         ))}
//       </View>

//       <View style={[styles.tableContainer, { backgroundColor: cardBg }]}>
//         <ScrollView horizontal showsHorizontalScrollIndicator={false}>
//           <View>
//             <View style={[styles.tableHeader, { backgroundColor: tableHeaderBg }]}>
//               <Text style={styles.thFixed}>FECHA</Text>
//               <Text style={styles.thFixed}>HORA</Text>
//               <Text style={styles.thUbicacion}>UBICACIÓN (LAT, LONG)</Text>
//               {columnasProductos.map(nombre => <Text key={nombre} style={styles.thDynamic}>{nombre.toUpperCase()}</Text>)}
//               <Text style={styles.thFixed}>TOTAL</Text>
//             </View>

//             <ScrollView 
//               style={{ maxHeight: 400 }}
//               refreshControl={<RefreshControl refreshing={loadingHistorial} onRefresh={cargar} tintColor="#E94560" />}
//             >
//               {(!ventas || ventas.length === 0) ? (
//                 <View style={styles.emptyContainer}><Text style={styles.emptyText}>Sin registros</Text></View>
//               ) : (
//                 ventas.map(v => {
//                   const fechaObj = new Date(v.created_at);
//                   return (
//                     <View key={v.id} style={[styles.tableRow, { borderBottomColor: rowBorder }]}>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>{fechaObj.toLocaleDateString([], { day: '2-digit', month: '2-digit' })}</Text>
//                       <Text style={[styles.tdFixed, { color: textPrimary }]}>{fechaObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
                      
//                       {/* Columna Ubicación Segura */}
//                       <Text style={[styles.tdUbicacion, { color: '#888' }]}>
//                         {v.ubicacion || 'Sin GPS'}
//                       </Text>

//                       {columnasProductos.map(nombreCol => {
//                         const itm = v.items?.find(i => i.nombre_producto === nombreCol);
//                         return <Text key={nombreCol} style={[styles.tdDynamic, { color: itm ? '#E94560' : '#444' }]}>{itm ? itm.cantidad : '-'}</Text>;
//                       })}
//                       <Text style={[styles.tdFixed, { color: '#E94560', fontWeight: '800' }]}>{simbolo}{Number(v.total).toFixed(2)}</Text>
//                     </View>
//                   );
//                 })
//               )}
//             </ScrollView>
//           </View>
//         </ScrollView>
//       </View>

//       <View style={styles.exportSection}>
//         <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#E94560' }]}><Text style={styles.exportText}>📄 EXPORTAR PDF</Text></TouchableOpacity>
//         <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#00D191' }]}><Text style={styles.exportText}>📊 EXPORTAR EXCEL</Text></TouchableOpacity>
//       </View>

//       <Modal visible={showCalendar} transparent animationType="fade">
//         <View style={styles.modalOverlay}>
//           <View style={[styles.calendarBox, { backgroundColor: isDark ? '#1C1C2E' : '#FFF' }]}>
//             <DatePicker mode="calendar" isGregorian={true} options={{ backgroundColor: isDark ? '#1C1C2E' : '#FFF', textHeaderColor: '#E94560', mainColor: '#E94560' }} onSelectedChange={() => setShowCalendar(false)} />
//             <TouchableOpacity onPress={() => setShowCalendar(false)} style={styles.closeBtn}><Text style={styles.closeBtnText}>CERRAR</Text></TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10 },
//   heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2, fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium' },
//   themeIcon: { width: 28, height: 28 }, 
//   lineSeparator: { height: 2, width: '100%', marginBottom: 15 },
//   filterSection: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginBottom: 15 },
//   calBtn: { padding: 8, borderRadius: 12, justifyContent: 'center' },
//   chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, justifyContent: 'center' },
//   chipActive: { backgroundColor: '#E94560' },
//   chipText: { fontSize: 12, fontWeight: '700', color: '#666' },
//   chipActiveText: { color: '#FFF' },
//   tableContainer: { marginHorizontal: 15, borderRadius: 25, overflow: 'hidden', flex: 1, marginBottom: 10 },
//   tableHeader: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15 },
//   thFixed: { width: 80, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   thUbicacion: { width: 115, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   thDynamic: { width: 95, fontSize: 9, fontWeight: '800', color: '#888', textAlign: 'center' },
//   tableRow: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 15, borderBottomWidth: 1, alignItems: 'center' },
//   tdFixed: { width: 80, fontSize: 11, fontWeight: '600', textAlign: 'center' },
//   tdUbicacion: { width: 115, fontSize: 10, fontWeight: '600', textAlign: 'center' },
//   tdDynamic: { width: 95, fontSize: 12, fontWeight: '700', textAlign: 'center' },
//   emptyContainer: { padding: 40, alignItems: 'center', width: SCREEN_WIDTH },
//   emptyText: { color: '#555', fontWeight: '600' },
//   exportSection: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 20, paddingHorizontal: 20 },
//   exportBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
//   exportText: { color: '#FFF', fontWeight: '900', fontSize: 10 },
//   modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', padding: 20 },
//   calendarBox: { borderRadius: 30, padding: 20 },
//   closeBtn: { alignSelf: 'center', marginTop: 10, padding: 10 },
//   closeBtnText: { color: '#E94560', fontWeight: '900' }
// });































import React, { useCallback, useState, useMemo } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl,
  Modal, Image, Dimensions, Platform
} from 'react-native';
// 1. Importar el Hook de Safe Area
import { useSafeAreaInsets } from 'react-native-safe-area-context'; 
import { useFocusEffect } from 'expo-router';
import { useThemeContext } from '@/components/ThemeContext';
import { useVentas } from '@/hooks/useVentas';
import DatePicker from 'react-native-modern-datepicker';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function HistorialScreen() {
  const { isDark, toggleTheme, simbolo } = useThemeContext();
  const { ventas, loadingHistorial, cargarHistorial } = useVentas();
  const [filtro, setFiltro] = useState<'Hoy' | 'Semana' | 'Mes' | 'Todo' | 'Custom'>('Hoy');
  const [showCalendar, setShowCalendar] = useState(false);

  // 2. Obtener los insets (márgenes seguros)
  const insets = useSafeAreaInsets();

  const cargar = useCallback(() => { cargarHistorial(); }, [cargarHistorial]);
  useFocusEffect(useCallback(() => { cargar(); }, [cargar]));

  // ... (tus useMemo se mantienen igual)
  const columnasProductos = useMemo(() => {
    const nombres = new Set<string>();
    if (!ventas) return [];
    ventas.forEach(v => {
      v.items?.forEach(item => {
        if (item.nombre_producto) nombres.add(item.nombre_producto);
      });
    });
    return Array.from(nombres);
  }, [ventas]);

  const bg = isDark ? '#07070F' : '#FFFFFF';
  const textPrimary = isDark ? '#FFFFFF' : '#1A1A2E';
  const cardBg = isDark ? '#161625' : '#F4F4FB';
  const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
  const tableHeaderBg = isDark ? '#1C1C2E' : '#E8E8F0';
  const rowBorder = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

  return (
    // 3. Cambiamos SafeAreaView por un View normal con padding dinámico
    <View style={[
      styles.safe, 
      { 
        backgroundColor: bg, 
        paddingTop: insets.top, // Esto empuja el contenido debajo de la hora
        paddingBottom: insets.bottom // Esto evita que los botones toquen la barra de navegación inferior
      }
    ]}>
      <View style={styles.headerRow}>
        <Text style={[styles.heroTitle, { color: textPrimary }]}>Historial</Text>
        <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
          <Image source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} style={styles.themeIcon} resizeMode="contain" />
        </TouchableOpacity>
      </View>

      <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

      {/* ... Resto de tu código (FilterSection, Table, etc) se mantiene igual ... */}
      
      <View style={styles.filterSection}>
        <TouchableOpacity style={[styles.calBtn, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }]} onPress={() => setShowCalendar(true)}>
          <Text style={{ fontSize: 18 }}>📅</Text>
        </TouchableOpacity>
        {['Hoy', 'Semana', 'Mes', 'Todo'].map(f => (
          <TouchableOpacity key={f} style={[styles.chip, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0FA' }, filtro === f && styles.chipActive]} onPress={() => setFiltro(f as any)}>
            <Text style={[styles.chipText, filtro === f && styles.chipActiveText]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={[styles.tableContainer, { backgroundColor: cardBg }]}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {/* Contenido de tu tabla */}
            <View>
                <View style={[styles.tableHeader, { backgroundColor: tableHeaderBg }]}>
                    <Text style={styles.thFixed}>FECHA</Text>
                    <Text style={styles.thFixed}>HORA</Text>
                    <Text style={styles.thUbicacion}>UBICACIÓN</Text>
                    {columnasProductos.map(nombre => <Text key={nombre} style={styles.thDynamic}>{nombre.toUpperCase()}</Text>)}
                    <Text style={styles.thFixed}>TOTAL</Text>
                </View>
                <ScrollView 
                    style={{ maxHeight: 400 }}
                    refreshControl={<RefreshControl refreshing={loadingHistorial} onRefresh={cargar} tintColor="#E94560" />}
                >
                    {/* Render de ventas igual a tu original */}
                </ScrollView>
            </View>
        </ScrollView>
      </View>

      <View style={styles.exportSection}>
        <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#E94560' }]}><Text style={styles.exportText}>📄 PDF</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.exportBtn, { backgroundColor: '#00D191' }]}><Text style={styles.exportText}>📊 EXCEL</Text></TouchableOpacity>
      </View>

      {/* Modal igual */}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  // Eliminamos el paddingTop manual de 15 porque ya lo da el inset
  headerRow: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    paddingHorizontal: 25, 
    paddingBottom: 10 
  },
  // ... resto de tus estilos
});   entonces este esta corregido para poner en github??
