// import React, { useState, useCallback } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity,
//   StyleSheet, SafeAreaView, TextInput, Modal,
//   ActivityIndicator, KeyboardAvoidingView, Platform, Image
// } from 'react-native';
// import { useThemeContext } from '@/components/ThemeContext';
// import { useProductos } from '@/hooks/useProductos';
// import { Toast } from '@/components/Toast';
// import type { Producto } from '@/types/database';

// // --- FORMULARIO CREAR / EDITAR ---
// function ProductoForm({ inicial, isDark, onGuardar, onClose, guardando }: any) {
//   const [form, setForm] = useState({
//     nombre: inicial.nombre ?? '',
//     precio: inicial.precio ?? '',
//   });
//   const [err, setErr] = useState('');

//   const inputBg  = isDark ? '#1C1C2E' : '#F4F4FB';
//   const textColor = isDark ? '#FFFFFF' : '#1A1A2E';
//   const cardBg   = isDark ? '#121221' : '#FFFFFF';

//   const handleGuardar = () => {
//     const nombreLimpio = form.nombre.trim();
//     const precioNum = parseFloat(form.precio.replace(',', '.'));
//     if (!nombreLimpio) { setErr('⚠️ El nombre es necesario'); return; }
//     if (!form.precio || isNaN(precioNum) || precioNum <= 0) {
//       setErr('⚠️ Precio inválido'); return;
//     }
//     onGuardar({ nombre: nombreLimpio, precio: precioNum });
//   };

//   return (
//     <View style={styles.modalOverlay}>
//       <TouchableOpacity style={{ flex: 1 }} onPress={onClose} activeOpacity={1} />
//       <KeyboardAvoidingView
//         behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
//         style={styles.keyboardView}
//       >
//         <View style={[styles.modalCard, { backgroundColor: cardBg }]}>
//           <View style={[styles.dragIndicator, { backgroundColor: isDark ? '#333' : '#DDD' }]} />

//           <View style={styles.formHeader}>
//             <Text style={[styles.formTitle, { color: textColor }]}>
//               {inicial.id ? 'Editar Producto' : 'Nuevo Producto'}
//             </Text>
//             <TouchableOpacity onPress={onClose} style={styles.closeCircle}>
//               <Text style={{ color: isDark ? '#FFF' : '#000', fontWeight: 'bold' }}>✕</Text>
//             </TouchableOpacity>
//           </View>

//           <View style={[styles.field, { backgroundColor: inputBg }]}>
//             <Text style={styles.fieldLabel}>Nombre del producto</Text>
//             <TextInput
//               value={form.nombre}
//               onChangeText={v => { setErr(''); setForm(p => ({ ...p, nombre: v })); }}
//               style={[styles.fieldInput, { color: textColor }]}
//               placeholder="Ej. Café Americano"
//               placeholderTextColor={isDark ? '#444' : '#CCC'}
//             />
//           </View>

//           <View style={[styles.field, { backgroundColor: inputBg }]}>
//             <Text style={styles.fieldLabel}>Precio (MXN)</Text>
//             <TextInput
//               keyboardType="decimal-pad"
//               value={form.precio}
//               onChangeText={v => { setErr(''); setForm(p => ({ ...p, precio: v.replace(/[^0-9.,]/g, '') })); }}
//               style={[styles.fieldInput, { color: '#E94560' }]}
//               placeholder="0.00"
//               placeholderTextColor="rgba(233,69,96,0.2)"
//             />
//           </View>

//           {err ? <Text style={styles.errText}>{err}</Text> : null}

//           <TouchableOpacity
//             style={[styles.saveBtn, guardando && { opacity: 0.7 }]}
//             onPress={handleGuardar}
//             disabled={guardando}
//           >
//             {guardando
//               ? <ActivityIndicator color="#fff" />
//               : <Text style={styles.saveBtnText}>Guardar</Text>}
//           </TouchableOpacity>
//         </View>
//       </KeyboardAvoidingView>
//     </View>
//   );
// }

// // --- PANTALLA PRINCIPAL ---
// export default function ConfigScreen() {
//   const { simbolo, isDark, toggleTheme } = useThemeContext();
//   const { productos, loading, crear, actualizar, eliminar } = useProductos();

//   const [formVisible, setFormVisible]         = useState(false);
//   const [editando, setEditando]               = useState<Producto | null>(null);
//   const [guardando, setGuardando]             = useState(false);
//   const [productoAEliminar, setProductoAEliminar] = useState<Producto | null>(null);
//   const [toast, setToast] = useState({
//     visible: false,
//     type: 'success' as 'success' | 'error',
//     title: '',
//   });

//   const cerrarForm = useCallback(() => {
//     setFormVisible(false);
//     setEditando(null);
//   }, []);

//   // Abre el modal de confirmación
//   const handleEliminar = useCallback((producto: Producto) => {
//     setProductoAEliminar(producto);
//   }, []);

//   // Ejecuta el soft-delete cuando el usuario confirma
//   const confirmarEliminar = useCallback(async () => {
//     if (!productoAEliminar) return;
//     const res = await eliminar(productoAEliminar.id);
//     setProductoAEliminar(null);
//     if (res.ok) {
//       setToast({ visible: true, type: 'success', title: 'Eliminado ✓' });
//     } else {
//       setToast({ visible: true, type: 'error', title: `Error: ${res.error}` });
//     }
//   }, [productoAEliminar, eliminar]);

//   const handleGuardar = useCallback(async (datosForm: any) => {
//     setGuardando(true);
//     const res = editando
//       ? await actualizar(editando.id, datosForm)
//       : await crear(datosForm);
//     setGuardando(false);
//     if (res.ok) {
//       cerrarForm();
//       setToast({ visible: true, type: 'success', title: editando ? 'Actualizado ✓' : 'Agregado ✓' });
//     } else {
//       setToast({ visible: true, type: 'error', title: 'Error de conexión' });
//     }
//   }, [editando, actualizar, crear, cerrarForm]);

//   const bg             = isDark ? '#07070F' : '#FFFFFF';
//   const textTitle      = isDark ? '#FFFFFF' : '#1A1A2E';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
//   const itemBg         = isDark ? '#161629' : '#F4F4FB';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>

//       {/* CABECERA */}
//       <View style={styles.headerRow}>
//         <Text style={[styles.heroTitle, { color: textTitle }]}>Configuración</Text>
//         <TouchableOpacity onPress={toggleTheme}>
//           <Image
//             source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')}
//             style={styles.themeIcon}
//             resizeMode="contain"
//           />
//         </TouchableOpacity>
//       </View>

//       <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

//       <ScrollView contentContainerStyle={{ padding: 16 }}>

//         {/* BOTÓN NUEVO PRODUCTO */}
//         <TouchableOpacity
//           style={[styles.actionAddBtn, { backgroundColor: isDark ? '#1C1C2E' : '#F0F0F7' }]}
//           onPress={() => { setEditando(null); setFormVisible(true); }}
//         >
//           <View style={styles.actionAddContent}>
//             <Image source={require('@/assets/mas.png')} style={styles.plusIcon} />
//             <Text style={[styles.actionAddText, { color: isDark ? '#FFF' : '#1A1A2E' }]}>
//               Nuevo Producto
//             </Text>
//           </View>
//         </TouchableOpacity>

//         {/* LISTA DE PRODUCTOS */}
//         <View style={styles.listContainer}>
//           {loading ? (
//             <ActivityIndicator color="#E94560" style={{ marginTop: 20 }} />
//           ) : (
//             productos.map((p) => (
//               <View key={p.id} style={[styles.prodItem, { backgroundColor: itemBg }]}>
//                 <View style={{ flex: 1 }}>
//                   <Text style={[styles.piName, { color: textTitle }]}>{p.nombre}</Text>
//                   <Text style={styles.piPrice}>{simbolo}{p.precio.toFixed(2)} MXN</Text>
//                 </View>

//                 <View style={styles.piActs}>
//                   <TouchableOpacity
//                     onPress={() => { setEditando(p); setFormVisible(true); }}
//                     style={styles.actBtn}
//                   >
//                     <Image
//                       source={require('@/assets/edit.png')}
//                       style={[styles.actionIcon, { tintColor: isDark ? '#fff' : '#1A1A2E' }]}
//                     />
//                   </TouchableOpacity>

//                   <TouchableOpacity
//                     onPress={() => handleEliminar(p)}
//                     style={styles.actBtn}
//                   >
//                     <Image
//                       source={require('@/assets/trash.png')}
//                       style={[styles.actionIcon, { tintColor: isDark ? '#fff' : '#1A1A2E' }]}
//                     />
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             ))
//           )}
//         </View>
//       </ScrollView>

//       {/* MODAL CONFIRMAR ELIMINAR */}
//       <Modal visible={!!productoAEliminar} animationType="fade" transparent>
//         <View style={styles.confirmOverlay}>
//           <View style={[styles.confirmCard, { backgroundColor: isDark ? '#161629' : '#FFF' }]}>
//             <Text style={[styles.confirmTitle, { color: isDark ? '#FFF' : '#1A1A2E' }]}>
//               Eliminar Producto
//             </Text>
//             <Text style={[styles.confirmMsg, { color: isDark ? '#AAA' : '#555' }]}>
//               ¿Seguro que deseas eliminar "{productoAEliminar?.nombre}"?
//             </Text>
//             <View style={styles.confirmBtns}>
//               <TouchableOpacity
//                 onPress={() => setProductoAEliminar(null)}
//                 style={[styles.confirmBtn, { backgroundColor: isDark ? '#2A2A3E' : '#F0F0F7' }]}
//               >
//                 <Text style={[styles.confirmBtnText, { color: isDark ? '#FFF' : '#1A1A2E' }]}>
//                   Cancelar
//                 </Text>
//               </TouchableOpacity>
//               <TouchableOpacity
//                 onPress={confirmarEliminar}
//                 style={[styles.confirmBtn, { backgroundColor: '#E94560' }]}
//               >
//                 <Text style={[styles.confirmBtnText, { color: '#FFF' }]}>Eliminar</Text>
//               </TouchableOpacity>
//             </View>
//           </View>
//         </View>
//       </Modal>

//       {/* MODAL FORMULARIO */}
//       <Modal visible={formVisible} animationType="slide" transparent>
//         <ProductoForm
//           inicial={editando ? { ...editando, precio: String(editando.precio) } : { nombre: '', precio: '' }}
//           isDark={isDark}
//           onGuardar={handleGuardar}
//           onClose={cerrarForm}
//           guardando={guardando}
//         />
//       </Modal>

//       <Toast
//         visible={toast.visible}
//         type={toast.type}
//         title={toast.title}
//         onDismiss={() => setToast(t => ({ ...t, visible: false }))}
//       />
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   headerRow: {
//     flexDirection: 'row', justifyContent: 'space-between',
//     alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10,
//   },
//   heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2 },
//   themeIcon: { width: 28, height: 28 },
//   lineSeparator: { height: 2, width: '100%', marginBottom: 10 },

//   actionAddBtn: {
//     borderRadius: 18, padding: 15, marginBottom: 20,
//     borderWidth: 1, borderColor: 'rgba(128,128,128,0.2)', elevation: 2,
//   },
//   actionAddContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
//   plusIcon: { width: 22, height: 22, marginRight: 12 },
//   actionAddText: { fontSize: 14, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.8 },

//   listContainer: { paddingBottom: 50 },
//   prodItem: { flexDirection: 'row', alignItems: 'center', padding: 18, borderRadius: 22, marginBottom: 12 },
//   piName: { fontSize: 15, fontWeight: '700' },
//   piPrice: { fontSize: 13, color: '#E94560', fontWeight: '800' },
//   piActs: { flexDirection: 'row', gap: 10 },
//   actBtn: { padding: 8, backgroundColor: 'rgba(128,128,128,0.1)', borderRadius: 12 },
//   actionIcon: { width: 18, height: 18 },

//   // Modal confirmar eliminar
//   confirmOverlay: {
//     flex: 1, backgroundColor: 'rgba(0,0,0,0.6)',
//     justifyContent: 'center', alignItems: 'center', padding: 30,
//   },
//   confirmCard: { borderRadius: 24, padding: 28, width: '100%' },
//   confirmTitle: { fontSize: 18, fontWeight: '900', marginBottom: 10 },
//   confirmMsg: { fontSize: 14, marginBottom: 24 },
//   confirmBtns: { flexDirection: 'row', gap: 12 },
//   confirmBtn: { flex: 1, padding: 14, borderRadius: 14, alignItems: 'center' },
//   confirmBtnText: { fontWeight: '700' },

//   // Modal formulario
//   modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
//   keyboardView: { width: '100%' },
//   modalCard: { borderTopLeftRadius: 35, borderTopRightRadius: 35, padding: 25, paddingBottom: Platform.OS === 'ios' ? 40 : 25 },
//   dragIndicator: { width: 40, height: 5, borderRadius: 3, alignSelf: 'center', marginBottom: 15 },
//   formHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
//   formTitle: { fontSize: 20, fontWeight: '900' },
//   closeCircle: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(128,128,128,0.1)', alignItems: 'center', justifyContent: 'center' },
//   field: { borderRadius: 16, padding: 15, marginBottom: 15 },
//   fieldLabel: { fontSize: 10, fontWeight: '800', color: '#888', marginBottom: 4, textTransform: 'uppercase' },
//   fieldInput: { fontSize: 16, fontWeight: '700' },
//   saveBtn: { backgroundColor: '#E94560', padding: 18, borderRadius: 16, alignItems: 'center', marginTop: 10 },
//   saveBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
//   errText: { color: '#E94560', textAlign: 'center', marginBottom: 10, fontWeight: '700', fontSize: 12 },
// });





















import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, SafeAreaView, TextInput, Modal,
  ActivityIndicator, KeyboardAvoidingView, Platform, Image
} from 'react-native';
import { useThemeContext } from '@/components/ThemeContext';
import { useProductos } from '@/hooks/useProductos';
import { Toast } from '@/components/Toast';
import type { Producto } from '@/types/database';

// --- FORMULARIO CREAR / EDITAR ---
function ProductoForm({ inicial, isDark, onGuardar, onClose, guardando }: any) {
  const [form, setForm] = useState({
    nombre: inicial.nombre ?? '',
    precio: inicial.precio ?? '',
  });
  const [err, setErr] = useState('');

  const inputBg  = isDark ? '#1C1C2E' : '#F4F4FB';
  const textColor = isDark ? '#FFFFFF' : '#1A1A2E';
  const cardBg   = isDark ? '#121221' : '#FFFFFF';

  const handleGuardar = () => {
    const nombreLimpio = form.nombre.trim();
    // Reemplazar coma por punto para el parseo flotante
    const precioStr = String(form.precio).replace(',', '.');
    const precioNum = parseFloat(precioStr);
    
    if (!nombreLimpio) { setErr('⚠️ El nombre es necesario'); return; }
    if (!form.precio || isNaN(precioNum) || precioNum <= 0) {
      setErr('⚠️ Precio inválido'); return;
    }
    onGuardar({ nombre: nombreLimpio, precio: precioNum });
  };

  return (
    <View style={styles.modalOverlay}>
      <TouchableOpacity style={{ flex: 1 }} onPress={onClose} activeOpacity={1} />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <View style={[styles.modalCard, { backgroundColor: cardBg }]}>
          <View style={[styles.dragIndicator, { backgroundColor: isDark ? '#333' : '#DDD' }]} />

          <View style={styles.formHeader}>
            <Text style={[styles.formTitle, { color: textColor }]}>
              {inicial.id ? 'Editar Producto' : 'Nuevo Producto'}
            </Text>
            <TouchableOpacity onPress={onClose} style={styles.closeCircle}>
              <Text style={{ color: isDark ? '#FFF' : '#000', fontWeight: 'bold' }}>✕</Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.field, { backgroundColor: inputBg }]}>
            <Text style={styles.fieldLabel}>Nombre del producto</Text>
            <TextInput
              value={form.nombre}
              onChangeText={v => { setErr(''); setForm(p => ({ ...p, nombre: v })); }}
              style={[styles.fieldInput, { color: textColor }]}
              placeholder="Ej. Café Americano"
              placeholderTextColor={isDark ? '#444' : '#CCC'}
            />
          </View>

          <View style={[styles.field, { backgroundColor: inputBg }]}>
            <Text style={styles.fieldLabel}>Precio (MXN)</Text>
            <TextInput
              keyboardType="decimal-pad"
              value={String(form.precio)}
              onChangeText={v => { setErr(''); setForm(p => ({ ...p, precio: v.replace(/[^0-9.,]/g, '') })); }}
              style={[styles.fieldInput, { color: '#E94560' }]}
              placeholder="0.00"
              placeholderTextColor="rgba(233,69,96,0.2)"
            />
          </View>

          {err ? <Text style={styles.errText}>{err}</Text> : null}

          <TouchableOpacity
            style={[styles.saveBtn, guardando && { opacity: 0.7 }]}
            onPress={handleGuardar}
            disabled={guardando}
          >
            {guardando
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.saveBtnText}>Guardar</Text>}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

// --- PANTALLA PRINCIPAL ---
export default function ConfigScreen() {
  const { simbolo, isDark, toggleTheme } = useThemeContext();
  const { productos, loading, crear, actualizar, eliminar } = useProductos();

  const [formVisible, setFormVisible]         = useState(false);
  const [editando, setEditando]                = useState<Producto | null>(null);
  const [guardando, setGuardando]              = useState(false);
  const [productoAEliminar, setProductoAEliminar] = useState<Producto | null>(null);
  const [toast, setToast] = useState({
    visible: false,
    type: 'success' as 'success' | 'error',
    title: '',
  });

  const cerrarForm = useCallback(() => {
    setFormVisible(false);
    setEditando(null);
  }, []);

  // Abre el modal de confirmación
  const handleEliminar = useCallback((producto: Producto) => {
    setProductoAEliminar(producto);
  }, []);

  // Ejecuta el soft-delete cuando el usuario confirma
  const confirmarEliminar = useCallback(async () => {
    if (!productoAEliminar) return;
    const res = await eliminar(productoAEliminar.id);
    setProductoAEliminar(null);
    if (res.ok) {
      setToast({ visible: true, type: 'success', title: 'Eliminado ✓' });
    } else {
      setToast({ visible: true, type: 'error', title: `Error: ${res.error}` });
    }
  }, [productoAEliminar, eliminar]);

  const handleGuardar = useCallback(async (datosForm: any) => {
    setGuardando(true);
    const res = editando
      ? await actualizar(editando.id, datosForm)
      : await crear(datosForm);
    setGuardando(false);
    if (res.ok) {
      cerrarForm();
      setToast({ visible: true, type: 'success', title: editando ? 'Actualizado ✓' : 'Agregado ✓' });
    } else {
      setToast({ visible: true, type: 'error', title: 'Error de conexión' });
    }
  }, [editando, actualizar, crear, cerrarForm]);

  const bg               = isDark ? '#07070F' : '#FFFFFF';
  const textTitle      = isDark ? '#FFFFFF' : '#1A1A2E';
  const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
  const itemBg         = isDark ? '#161629' : '#F4F4FB';

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>

      {/* CABECERA */}
      <View style={styles.headerRow}>
        <Text style={[styles.heroTitle, { color: textTitle }]}>Configuración</Text>
        <TouchableOpacity onPress={toggleTheme}>
          <Image
            source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')}
            style={styles.themeIcon}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>

      <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />

      {/* LISTA DE PRODUCTOS */}
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.listContainer}>
          {loading ? (
            <ActivityIndicator color="#E94560" style={{ marginTop: 20 }} />
          ) : (
            productos.map((p) => (
              <View key={p.id} style={[styles.prodItem, { backgroundColor: itemBg }]}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.piName, { color: textTitle }]}>{p.nombre}</Text>
                  <Text style={styles.piPrice}>{simbolo}{p.precio.toFixed(2)} MXN</Text>
                </View>

                <View style={styles.piActs}>
                  <TouchableOpacity
                    onPress={() => { setEditando(p); setFormVisible(true); }}
                    style={styles.actBtn}
                  >
                    <Image
                      source={require('@/assets/edit.png')}
                      style={[styles.actionIcon, { tintColor: isDark ? '#fff' : '#1A1A2E' }]}
                    />
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => handleEliminar(p)}
                    style={styles.actBtn}
                  >
                    <Image
                      source={require('@/assets/trash.png')}
                      style={[styles.actionIcon, { tintColor: isDark ? '#fff' : '#1A1A2E' }]}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>

      {/* BOTÓN CIRCULAR FLOTANTE (NUEVO PRODUCTO) */}
      <TouchableOpacity
        style={[styles.actionAddBtn, { backgroundColor: '#E94560' }]} // Color acento para que resalte
        onPress={() => { setEditando(null); setFormVisible(true); }}
      >
        <Image 
          source={require('@/assets/mas.png')} 
          style={[styles.plusIcon, { tintColor: '#FFFFFF' }]} // Icono blanco
        />
      </TouchableOpacity>

      {/* MODAL CONFIRMAR ELIMINAR */}
      <Modal visible={!!productoAEliminar} animationType="fade" transparent>
        <View style={styles.confirmOverlay}>
          <View style={[styles.confirmCard, { backgroundColor: isDark ? '#161629' : '#FFF' }]}>
            <Text style={[styles.confirmTitle, { color: isDark ? '#FFF' : '#1A1A2E' }]}>
              Eliminar Producto
            </Text>
            <Text style={[styles.confirmMsg, { color: isDark ? '#AAA' : '#555' }]}>
              ¿Seguro que deseas eliminar "{productoAEliminar?.nombre}"?
            </Text>
            <View style={styles.confirmBtns}>
              <TouchableOpacity
                onPress={() => setProductoAEliminar(null)}
                style={[styles.confirmBtn, { backgroundColor: isDark ? '#2A2A3E' : '#F0F0F7' }]}
              >
                <Text style={[styles.confirmBtnText, { color: isDark ? '#FFF' : '#1A1A2E' }]}>
                  Cancelar
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={confirmarEliminar}
                style={[styles.confirmBtn, { backgroundColor: '#E94560' }]}
              >
                <Text style={[styles.confirmBtnText, { color: '#FFF' }]}>Eliminar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* MODAL FORMULARIO */}
      <Modal visible={formVisible} animationType="slide" transparent>
        <ProductoForm
          inicial={editando ? { ...editando, precio: String(editando.precio) } : { nombre: '', precio: '' }}
          isDark={isDark}
          onGuardar={handleGuardar}
          onClose={cerrarForm}
          guardando={guardando}
        />
      </Modal>

      <Toast
        visible={toast.visible}
        type={toast.type}
        title={toast.title}
        onDismiss={() => setToast(t => ({ ...t, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  headerRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10,
  },
  heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2 },
  themeIcon: { width: 28, height: 28 },
  lineSeparator: { height: 2, width: '100%', marginBottom: 10 },

  scrollContent: { padding: 16, paddingBottom: 100 }, // Padding bottom extra para que el último item no tape el botón

  // Botón circular modificado
  actionAddBtn: {
    position: 'absolute', // Posicionamiento absoluto
    bottom: 30,           // Distancia desde abajo
    right: 25,            // Distancia desde la derecha
    width: 60,            // Ancho fijo
    height: 60,           // Alto fijo (igual al ancho para círculo)
    borderRadius: 30,     // Mitad del ancho/alto para círculo perfecto
    justifyContent: 'center', 
    alignItems: 'center',
    elevation: 5,         // Sombra en Android
    shadowColor: '#000',  // Sombra en iOS
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    zIndex: 10,           // Asegurar que esté por encima
  },
  plusIcon: { width: 26, height: 26 }, // Icono un poco más grande

  listContainer: { paddingBottom: 20 },
  prodItem: { flexDirection: 'row', alignItems: 'center', padding: 18, borderRadius: 22, marginBottom: 12 },
  piName: { fontSize: 15, fontWeight: '700' },
  piPrice: { fontSize: 13, color: '#E94560', fontWeight: '800' },
  piActs: { flexDirection: 'row', gap: 10, marginLeft: 10 },
  actBtn: { padding: 8, backgroundColor: 'rgba(128,128,128,0.1)', borderRadius: 12 },
  actionIcon: { width: 18, height: 18 },

  // Modal confirmar eliminar
  confirmOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center', alignItems: 'center', padding: 30,
  },
  confirmCard: { borderRadius: 24, padding: 28, width: '100%' },
  confirmTitle: { fontSize: 18, fontWeight: '900', marginBottom: 10 },
  confirmMsg: { fontSize: 14, marginBottom: 24 },
  confirmBtns: { flexDirection: 'row', gap: 12 },
  confirmBtn: { flex: 1, padding: 14, borderRadius: 14, alignItems: 'center' },
  confirmBtnText: { fontWeight: '700' },

  // Modal formulario
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  keyboardView: { width: '100%' },
  modalCard: { borderTopLeftRadius: 35, borderTopRightRadius: 35, padding: 25, paddingBottom: Platform.OS === 'ios' ? 40 : 25 },
  dragIndicator: { width: 40, height: 5, borderRadius: 3, alignSelf: 'center', marginBottom: 15 },
  formHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
  formTitle: { fontSize: 20, fontWeight: '900' },
  closeCircle: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(128,128,128,0.1)', alignItems: 'center', justifyContent: 'center' },
  field: { borderRadius: 16, padding: 15, marginBottom: 15 },
  fieldLabel: { fontSize: 10, fontWeight: '800', color: '#888', marginBottom: 4, textTransform: 'uppercase' },
  fieldInput: { fontSize: 16, fontWeight: '700' },
  saveBtn: { backgroundColor: '#E94560', padding: 18, borderRadius: 16, alignItems: 'center', marginTop: 10 },
  saveBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  errText: { color: '#E94560', textAlign: 'center', marginBottom: 10, fontWeight: '700', fontSize: 12 },
});
