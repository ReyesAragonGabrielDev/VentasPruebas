// import React, { useState, useCallback, useReducer } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity, Image,
//   StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl, Platform,
// } from 'react-native';
// import { useFocusEffect } from 'expo-router';
// import { useThemeContext } from '@/components/ThemeContext';
// import { ProductoCard } from '@/components/ProductoCard';
// import { Toast } from '@/components/Toast';
// import { useProductos } from '@/hooks/useProductos';
// import { useVentas } from '@/hooks/useVentas';
// import { useLocation } from '@/hooks/useLocation';

// type CartState = Record<string, number>;
// type CartAction = | { type: 'SET'; id: string; cantidad: number } | { type: 'RESET_ALL' };

// function cartReducer(state: CartState, action: CartAction): CartState {
//   switch (action.type) {
//     case 'SET': return { ...state, [action.id]: action.cantidad };
//     case 'RESET_ALL': return {};
//     default: return state;
//   }
// }

// export default function InicioScreen() {
//   const { isDark, toggleTheme, simbolo } = useThemeContext();
//   const { productos, loading, refetch } = useProductos();
//   const { enviando, enviarVenta } = useVentas();
//   const { obtenerCoordenadas } = useLocation();

//   const [cart, dispatch] = useReducer(cartReducer, {});
//   const [toast, setToast] = useState({ visible: false, type: 'success' as const, title: '', subtitle: '' });

//   useFocusEffect(useCallback(() => { 
//     refetch(); 
//   }, [refetch]));

//   const total = productos.reduce((acc, p) => acc + p.precio * (cart[p.id] ?? 0), 0);
//   const hayItems = total > 0;
//   const fechaActual = new Date().toLocaleDateString('es-MX', { 
//     weekday: 'long', 
//     day: 'numeric', 
//     month: 'long' 
//   }).toUpperCase();

//   const handleEnviar = async () => {
//     const itemsParaEnviar = productos.filter(p => (cart[p.id] ?? 0) > 0).map(p => ({ producto: p, cantidad: cart[p.id] }));
//     if (itemsParaEnviar.length === 0) return;
//     const coords = await obtenerCoordenadas();
//     const res = await enviarVenta(itemsParaEnviar, 'MXN', coords);
//     if (res.ok) {
//       setToast({ visible: true, type: 'success', title: '¡Venta Guardada!', subtitle: 'Sincronizado con GPS ✓' });
//       dispatch({ type: 'RESET_ALL' });
//     } else {
//       setToast({ visible: true, type: 'error', title: 'Error', subtitle: res.error || 'Fallo al guardar.' });
//     }
//   };

//   const bg = isDark ? '#07070F' : '#FFFFFF';
//   const textMain = isDark ? '#FFFFFF' : '#1A1A2E';
//   const textSub = isDark ? 'rgba(255,255,255,0.4)' : '#666';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
//       <View style={styles.container}>
//         <View style={styles.headerTop}>
//           <Text style={[styles.heroTitle, { color: textMain }]}>Inicio</Text>
//           <View style={styles.headerRight}>
//             {hayItems && (
//               <TouchableOpacity style={styles.resetBtn} onPress={() => dispatch({ type: 'RESET_ALL' })}>
//                 <Text style={styles.resetText}>Reiniciar</Text>
//               </TouchableOpacity>
//             )}
//             <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
//               <Image 
//                 source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} 
//                 style={styles.themeIcon} 
//                 resizeMode="contain" 
//               />
//             </TouchableOpacity>
//           </View>
//         </View>

//         <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />
//         <Text style={[styles.fecha, { color: textSub }]}>{fechaActual}</Text>

//         {loading ? (
//           <View style={styles.center}><ActivityIndicator color="#E94560" size="large" /></View>
//         ) : (
//           <ScrollView 
//             showsVerticalScrollIndicator={false} 
//             contentContainerStyle={{ paddingBottom: 120 }}
//             refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} tintColor="#E94560" />}
//           >
//             <View style={styles.grid}>
//               {productos.map(p => (
//                 <View key={p.id} style={styles.cardWrapper}>
//                   <ProductoCard 
//                     producto={p} 
//                     cantidad={cart[p.id] ?? 0} 
//                     simbolo={simbolo} 
//                     isDark={isDark} 
//                     onCantidadChange={(id, val) => dispatch({ type: 'SET', id, cantidad: val })} 
//                   />
//                 </View>
//               ))}
//             </View>
//           </ScrollView>
//         )}

//         {/* BARRA DE TOTAL */}
//         <View style={[styles.totalBar, { backgroundColor: isDark ? '#161629' : '#F0F0FA' }]}>
//           <View>
//             <Text style={[styles.totalLabel, { color: isDark ? 'rgba(255,255,255,0.4)' : '#888' }]}>TOTAL A COBRAR</Text>
//             <Text style={styles.totalAmt}>{simbolo}{total.toFixed(2)}</Text>
//           </View>
          
//           <TouchableOpacity 
//             style={[styles.sendBtn, (!hayItems || enviando) && styles.sendDisabled]} 
//             disabled={!hayItems || enviando} 
//             onPress={handleEnviar}
//             activeOpacity={0.8}
//           >
//             {enviando ? (
//               <ActivityIndicator color="#fff" size="small" />
//             ) : (
//               <Text style={styles.sendText}>Enviar</Text>
//             )}
//           </TouchableOpacity>
//         </View>

//         <Toast visible={toast.visible} type={toast.type} title={toast.title} onDismiss={() => setToast(t => ({ ...t, visible: false }))} />
//       </View>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   container: { flex: 1 },
//   headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10 },
//   heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2, fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium' },
//   headerRight: { flexDirection: 'row', alignItems: 'center', gap: 15 },
//   lineSeparator: { height: 2, width: '100%' },
//   fecha: { fontSize: 10, fontWeight: '800', letterSpacing: 1, paddingHorizontal: 25, marginTop: 12, marginBottom: 10 },
//   themeIcon: { width: 28, height: 28 },
//   resetBtn: { backgroundColor: 'rgba(233, 69, 96, 0.12)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
//   resetText: { color: '#E94560', fontSize: 11, fontWeight: '700' },
//   grid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10 },
//   cardWrapper: { width: '50%', padding: 5 },
//   center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  
//   totalBar: { 
//     flexDirection: 'row', 
//     justifyContent: 'space-between', 
//     alignItems: 'center', 
//     position: 'absolute', 
//     bottom: 20, 
//     left: 16, 
//     right: 16, 
//     borderRadius: 25, 
//     padding: 18, 
//     elevation: 8, 
//     shadowColor: "#000", 
//     shadowOffset: { width: 0, height: 4 }, 
//     shadowOpacity: 0.2, 
//     shadowRadius: 10 
//   },
//   totalLabel: { fontSize: 10, fontWeight: '800' },
//   totalAmt: { fontSize: 26, fontWeight: '900', color: '#E94560' },
  
//   sendBtn: { 
//     backgroundColor: '#E94560', // El rojo correcto que ya tenías
//     paddingHorizontal: 28, 
//     height: 50, 
//     borderRadius: 15, 
//     justifyContent: 'center', 
//     alignItems: 'center',
//     elevation: 4,
//     shadowColor: "#E94560",
//     shadowOffset: { width: 0, height: 2 },
//     shadowOpacity: 0.3,
//     shadowRadius: 5
//   },
//   sendText: {
//     color: '#FFFFFF',
//     fontSize: 15,
//     fontWeight: '700',
//     letterSpacing: 0.2
//   },
//   sendDisabled: { 
//     // Mantenemos el fondo rojo (#E94560) al no poner backgroundColor aquí,
//     // ya que hereda el del estilo principal 'sendBtn'.
//     opacity: 0.35, // Bajamos la opacidad para que el rojo se vea "apagado"
//   },
// });




























import React, { useState, useCallback, useReducer } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, Image,
  StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl, Platform,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useThemeContext } from '@/components/ThemeContext';
import { ProductoCard } from '@/components/ProductoCard';
import { Toast } from '@/components/Toast';
import { useProductos } from '@/hooks/useProductos';
import { useVentas } from '@/hooks/useVentas';
import { useLocation } from '@/hooks/useLocation';

type CartState = Record<string, number>;
type CartAction = | { type: 'SET'; id: string; cantidad: number } | { type: 'RESET_ALL' };

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case 'SET': return { ...state, [action.id]: action.cantidad };
    case 'RESET_ALL': return {};
    default: return state;
  }
}

export default function InicioScreen() {
  const { isDark, toggleTheme, simbolo } = useThemeContext();
  const { productos, loading, refetch } = useProductos();
  const { enviando, enviarVenta } = useVentas();
  const { obtenerCoordenadas } = useLocation();

  const [cart, dispatch] = useReducer(cartReducer, {});
  const [toast, setToast] = useState({ visible: false, type: 'success' as const, title: '', subtitle: '' });

  useFocusEffect(useCallback(() => { 
    refetch(); 
  }, [refetch]));

  const total = productos.reduce((acc, p) => acc + p.precio * (cart[p.id] ?? 0), 0);
  const hayItems = total > 0;
  const fechaActual = new Date().toLocaleDateString('es-MX', { 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long' 
  }).toUpperCase();

  const handleEnviar = async () => {
    const itemsParaEnviar = productos.filter(p => (cart[p.id] ?? 0) > 0).map(p => ({ producto: p, cantidad: cart[p.id] }));
    if (itemsParaEnviar.length === 0) return;

    // CAPTURA DE UBICACIÓN AUTOMÁTICA
    const coords = await obtenerCoordenadas();
    
    const res = await enviarVenta(itemsParaEnviar, 'MXN', coords);
    if (res.ok) {
      setToast({ visible: true, type: 'success', title: '¡Venta Guardada!', subtitle: 'Sincronizado con GPS ✓' });
      dispatch({ type: 'RESET_ALL' });
    } else {
      setToast({ visible: true, type: 'error', title: 'Error', subtitle: res.error || 'Fallo al guardar.' });
    }
  };

  const bg = isDark ? '#07070F' : '#FFFFFF';
  const textMain = isDark ? '#FFFFFF' : '#1A1A2E';
  const textSub = isDark ? 'rgba(255,255,255,0.4)' : '#666';
  const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
      <View style={styles.container}>
        <View style={styles.headerTop}>
          <Text style={[styles.heroTitle, { color: textMain }]}>Inicio</Text>
          <div style={styles.headerRight}>
            {hayItems && (
              <TouchableOpacity style={styles.resetBtn} onPress={() => dispatch({ type: 'RESET_ALL' })}>
                <Text style={styles.resetText}>Reiniciar</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
              <Image 
                source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} 
                style={styles.themeIcon} 
                resizeMode="contain" 
              />
            </TouchableOpacity>
          </div>
        </View>

        <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />
        <Text style={[styles.fecha, { color: textSub }]}>{fechaActual}</Text>

        {loading ? (
          <View style={styles.center}><ActivityIndicator color="#E94560" size="large" /></View>
        ) : (
          <ScrollView 
            showsVerticalScrollIndicator={false} 
            contentContainerStyle={{ paddingBottom: 120 }}
            refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} tintColor="#E94560" />}
          >
            <View style={styles.grid}>
              {productos.map(p => (
                <View key={p.id} style={styles.cardWrapper}>
                  <ProductoCard 
                    producto={p} 
                    cantidad={cart[p.id] ?? 0} 
                    simbolo={simbolo} 
                    isDark={isDark} 
                    onCantidadChange={(id, val) => dispatch({ type: 'SET', id, cantidad: val })} 
                  />
                </View>
              ))}
            </View>
          </ScrollView>
        )}

        <View style={[styles.totalBar, { backgroundColor: isDark ? '#161629' : '#F0F0FA' }]}>
          <View>
            <Text style={[styles.totalLabel, { color: isDark ? 'rgba(255,255,255,0.4)' : '#888' }]}>TOTAL A COBRAR</Text>
            <Text style={styles.totalAmt}>{simbolo}{total.toFixed(2)}</Text>
          </View>
          
          <TouchableOpacity 
            style={[styles.sendBtn, (!hayItems || enviando) && styles.sendDisabled]} 
            disabled={!hayItems || enviando} 
            onPress={handleEnviar}
            activeOpacity={0.8}
          >
            {enviando ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text style={styles.sendText}>Enviar</Text>
            )}
          </TouchableOpacity>
        </View>

        <Toast visible={toast.visible} type={toast.type} title={toast.title} onDismiss={() => setToast(t => ({ ...t, visible: false }))} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  container: { flex: 1 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10 },
  heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2, fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 15 },
  lineSeparator: { height: 2, width: '100%' },
  fecha: { fontSize: 10, fontWeight: '800', letterSpacing: 1, paddingHorizontal: 25, marginTop: 12, marginBottom: 10 },
  themeIcon: { width: 28, height: 28 },
  resetBtn: { backgroundColor: 'rgba(233, 69, 96, 0.12)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  resetText: { color: '#E94560', fontSize: 11, fontWeight: '700' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10 },
  cardWrapper: { width: '50%', padding: 5 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  totalBar: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    position: 'absolute', 
    bottom: 20, 
    left: 16, 
    right: 16, 
    borderRadius: 25, 
    padding: 18, 
    elevation: 8, 
    shadowColor: "#000", 
    shadowOffset: { width: 0, height: 4 }, 
    shadowOpacity: 0.2, 
    shadowRadius: 10 
  },
  totalLabel: { fontSize: 10, fontWeight: '800' },
  totalAmt: { fontSize: 26, fontWeight: '900', color: '#E94560' },
  sendBtn: { 
    backgroundColor: '#E94560', 
    paddingHorizontal: 28, 
    height: 50, 
    borderRadius: 15, 
    justifyContent: 'center', 
    alignItems: 'center',
    elevation: 4,
    shadowColor: "#E94560",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5
  },
  sendText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700', letterSpacing: 0.2 },
  sendDisabled: { opacity: 0.35 },
});
































// import React, { useState, useCallback, useReducer } from 'react';
// import {
//   View, Text, ScrollView, TouchableOpacity, Image,
//   StyleSheet, SafeAreaView, ActivityIndicator, RefreshControl, Platform,
// } from 'react-native';
// import { useFocusEffect } from 'expo-router';
// import { useThemeContext } from '@/components/ThemeContext';
// import { ProductoCard } from '@/components/ProductoCard';
// import { Toast } from '@/components/Toast';
// import { useProductos } from '@/hooks/useProductos';
// import { useVentas } from '@/hooks/useVentas';
// import { useLocation } from '@/hooks/useLocation';

// type CartState = Record<string, number>;
// type CartAction = | { type: 'SET'; id: string; cantidad: number } | { type: 'RESET_ALL' };

// function cartReducer(state: CartState, action: CartAction): CartState {
//   switch (action.type) {
//     case 'SET': return { ...state, [action.id]: action.cantidad };
//     case 'RESET_ALL': return {};
//     default: return state;
//   }
// }

// export default function InicioScreen() {
//   const { isDark, toggleTheme, simbolo } = useThemeContext();
//   const { productos, loading, refetch } = useProductos();
//   const { enviando, enviarVenta } = useVentas();
//   const { obtenerCoordenadas, solicitarPermiso } = useLocation();

//   const [cart, dispatch] = useReducer(cartReducer, {});
//   const [toast, setToast] = useState({ visible: false, type: 'success' as const, title: '', subtitle: '' });

//   useFocusEffect(useCallback(() => { 
//     refetch(); 
//   }, [refetch]));

//   const total = productos.reduce((acc, p) => acc + p.precio * (cart[p.id] ?? 0), 0);
//   const hayItems = total > 0;
//   const fechaActual = new Date().toLocaleDateString('es-MX', { 
//     weekday: 'long', day: 'numeric', month: 'long' 
//   }).toUpperCase();

//   const handleEnviar = async () => {
//     if (enviando) return;
    
//     try {
//       const itemsParaEnviar = productos
//         .filter(p => (cart[p.id] ?? 0) > 0)
//         .map(p => ({ producto: p, cantidad: cart[p.id] }));

//       if (itemsParaEnviar.length === 0) return;

//       // PASO 1: Asegurar permiso
//       await solicitarPermiso();

//       // PASO 2: Obtener coordenadas
//       const coords = await obtenerCoordenadas();
      
//       // PASO 3: Enviar a Supabase
//       const res = await enviarVenta(itemsParaEnviar, 'MXN', coords);

//       if (res.ok) {
//         setToast({ 
//           visible: true, 
//           type: 'success', 
//           title: '¡Venta Guardada!', 
//           subtitle: coords.latitud ? 'Ubicación registrada ✓' : 'Guardado sin ubicación' 
//         });
//         dispatch({ type: 'RESET_ALL' });
//       } else {
//         setToast({ visible: true, type: 'error', title: 'Error', subtitle: res.error || 'Fallo al guardar.' });
//       }
//     } catch (err) {
//       setToast({ visible: true, type: 'error', title: 'Error', subtitle: 'Error al procesar venta.' });
//     }
//   };

//   const bg = isDark ? '#07070F' : '#FFFFFF';
//   const textMain = isDark ? '#FFFFFF' : '#1A1A2E';
//   const textSub = isDark ? 'rgba(255,255,255,0.4)' : '#666';
//   const separatorColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';

//   return (
//     <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
//       <View style={styles.container}>
//         <View style={styles.headerTop}>
//           <Text style={[styles.heroTitle, { color: textMain }]}>Inicio</Text>
//           <View style={styles.headerRight}>
//             {hayItems && (
//               <TouchableOpacity style={styles.resetBtn} onPress={() => dispatch({ type: 'RESET_ALL' })}>
//                 <Text style={styles.resetText}>Reiniciar</Text>
//               </TouchableOpacity>
//             )}
//             <TouchableOpacity onPress={toggleTheme} activeOpacity={0.7}>
//               <Image 
//                 source={isDark ? require('@/assets/sol.png') : require('@/assets/luna.png')} 
//                 style={styles.themeIcon} 
//                 resizeMode="contain" 
//               />
//             </TouchableOpacity>
//           </View>
//         </View>

//         <View style={[styles.lineSeparator, { backgroundColor: separatorColor }]} />
//         <Text style={[styles.fecha, { color: textSub }]}>{fechaActual}</Text>

//         {loading ? (
//           <View style={styles.center}><ActivityIndicator color="#E94560" size="large" /></View>
//         ) : (
//           <ScrollView 
//             showsVerticalScrollIndicator={false} 
//             contentContainerStyle={{ paddingBottom: 120 }}
//             refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} tintColor="#E94560" />}
//           >
//             <View style={styles.grid}>
//               {productos.map(p => (
//                 <View key={p.id} style={styles.cardWrapper}>
//                   <ProductoCard 
//                     producto={p} 
//                     cantidad={cart[p.id] ?? 0} 
//                     simbolo={simbolo} 
//                     isDark={isDark} 
//                     onCantidadChange={(id, val) => dispatch({ type: 'SET', id, cantidad: val })} 
//                   />
//                 </View>
//               ))}
//             </View>
//           </ScrollView>
//         )}

//         <View style={[styles.totalBar, { backgroundColor: isDark ? '#161629' : '#F0F0FA' }]}>
//           <View>
//             <Text style={[styles.totalLabel, { color: isDark ? 'rgba(255,255,255,0.4)' : '#888' }]}>TOTAL A COBRAR</Text>
//             <Text style={styles.totalAmt}>{simbolo}{total.toFixed(2)}</Text>
//           </View>
//           <TouchableOpacity 
//             style={[styles.sendBtn, (!hayItems || enviando) && styles.sendDisabled]} 
//             disabled={!hayItems || enviando} 
//             onPress={handleEnviar}
//             activeOpacity={0.8}
//           >
//             {enviando ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.sendText}>Enviar</Text>}
//           </TouchableOpacity>
//         </View>

//         <Toast visible={toast.visible} type={toast.type} title={toast.title} onDismiss={() => setToast(t => ({ ...t, visible: false }))} />
//       </View>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   safe: { flex: 1 },
//   container: { flex: 1 },
//   headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 25, paddingTop: 15, paddingBottom: 10 },
//   heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.2, fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif-medium' },
//   headerRight: { flexDirection: 'row', alignItems: 'center', gap: 15 },
//   lineSeparator: { height: 2, width: '100%' },
//   fecha: { fontSize: 10, fontWeight: '800', letterSpacing: 1, paddingHorizontal: 25, marginTop: 12, marginBottom: 10 },
//   themeIcon: { width: 28, height: 28 },
//   resetBtn: { backgroundColor: 'rgba(233, 69, 96, 0.12)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
//   resetText: { color: '#E94560', fontSize: 11, fontWeight: '700' },
//   grid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10 },
//   cardWrapper: { width: '50%', padding: 5 },
//   center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
//   totalBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', position: 'absolute', bottom: 20, left: 16, right: 16, borderRadius: 25, padding: 18, elevation: 8, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 10 },
//   totalLabel: { fontSize: 10, fontWeight: '800' },
//   totalAmt: { fontSize: 26, fontWeight: '900', color: '#E94560' },
//   sendBtn: { backgroundColor: '#E94560', paddingHorizontal: 28, height: 50, borderRadius: 15, justifyContent: 'center', alignItems: 'center', elevation: 4, shadowColor: "#E94560", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 5 },
//   sendText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700', letterSpacing: 0.2 },
//   sendDisabled: { opacity: 0.35 },
// });
