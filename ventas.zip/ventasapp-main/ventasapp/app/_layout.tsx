


// import { useEffect, useState } from 'react';
// import { Stack, useRouter, useSegments } from 'expo-router';
// import { StatusBar } from 'expo-status-bar';
// import { GestureHandlerRootView } from 'react-native-gesture-handler';
// import { StyleSheet, View, ActivityIndicator } from 'react-native';
// import { ThemeProvider, useThemeContext } from '@/components/ThemeContext';
// import { supabase } from '@/lib/supabase'; // Asegúrate de que la ruta sea correcta

// function RootLayoutNav() {
//   const { isDark } = useThemeContext();
//   const [initializing, setInitializing] = useState(true);
//   const segments = useSegments();
//   const router = useRouter();

//   useEffect(() => {
//     // Escuchamos cambios en la sesión de Supabase
//     const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
//       const inTabsGroup = segments[0] === '(tabs)';

//       if (!session && inTabsGroup) {
//         // 1. Si NO hay sesión y el usuario intenta entrar a las tabs -> Login
//         router.replace('/login');
//       } else if (session && segments[0] !== '(tabs)') {
//         // 2. Si SÍ hay sesión y el usuario NO está en las tabs -> App principal
//         router.replace('/(tabs)');
//       }
      
//       setInitializing(false);
//     });

//     return () => {
//       authListener.subscription.unsubscribe();
//     };
//   }, [segments]);

//   // Pantalla de carga mientras verificamos la sesión inicial
//   if (initializing) {
//     return (
//       <View style={[styles.loadingContainer, { backgroundColor: isDark ? '#07070F' : '#FFF' }]}>
//         <ActivityIndicator size="large" color="#E94560" />
//       </View>
//     );
//   }

//   return (
//     <>
//       <StatusBar style={isDark ? 'light' : 'dark'} />
//       <Stack screenOptions={{ headerShown: false }}>
//         {/* Definimos las rutas disponibles */}
//         <Stack.Screen name="login" /> 
//         <Stack.Screen name="(tabs)" />
//       </Stack>
//     </>
//   );
// }

// export default function RootLayout() {
//   return (
//     <GestureHandlerRootView style={styles.root}>
//       <ThemeProvider>
//         <RootLayoutNav />
//       </ThemeProvider>
//     </GestureHandlerRootView>
//   );
// }

// const styles = StyleSheet.create({
//   root: { flex: 1 },
//   loadingContainer: { 
//     flex: 1, 
//     justifyContent: 'center', 
//     alignItems: 'center' 
//   },
// });































// import { useEffect } from 'react';
// import { Stack } from 'expo-router';
// import { StatusBar } from 'expo-status-bar';
// import { GestureHandlerRootView } from 'react-native-gesture-handler';
// import { StyleSheet } from 'react-native';
// import { ThemeProvider, useThemeContext } from '@/components/ThemeContext';

// function RootLayoutNav() {
//   const { isDark } = useThemeContext();

//   return (
//     <>
//       <StatusBar style={isDark ? 'light' : 'dark'} />
//       <Stack screenOptions={{ headerShown: false }}>
//         <Stack.Screen name="(tabs)" />
//       </Stack>
//     </>
//   );
// }

// export default function RootLayout() {
//   return (
//     <GestureHandlerRootView style={styles.root}>
//       <ThemeProvider>
//         <RootLayoutNav />
//       </ThemeProvider>
//     </GestureHandlerRootView>
//   );
// }

// const styles = StyleSheet.create({
//   root: { flex: 1 },
// });













































import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StyleSheet } from 'react-native';
import { ThemeProvider, useThemeContext } from '@/components/ThemeContext';
// 1. IMPORTAR PROVIDER
import { SafeAreaProvider } from 'react-native-safe-area-context';

function RootLayoutNav() {
  const { isDark } = useThemeContext();

  return (
    <>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={styles.root}>
      {/* 2. ENVOLVER TODO EL CONTENIDO */}
      <SafeAreaProvider>
        <ThemeProvider>
          <RootLayoutNav />
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
});
